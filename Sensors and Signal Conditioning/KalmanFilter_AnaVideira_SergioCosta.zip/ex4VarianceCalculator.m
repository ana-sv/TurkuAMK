function variance = ex4VarianceCalculator(mea,avg_mea)
    
    sum=0;
    for i = 0:length(mea)-1
        squareOfDeviation = (avg_mea-mea(i+1))^2;
        sum = sum + squareOfDeviation;
    end
    variance = sum/length(mea);
end