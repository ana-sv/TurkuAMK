function xp = newPredictedState(nAxis,deltaT,x,u,w)
    %% Build the matrix A
    matrixA = eye(nAxis*2);
    for i = 1:width(matrixA)-nAxis
        matrixA(i,nAxis+i) = deltaT;
    end

    %% Build the matrix B
    matrixB = zeros(nAxis*2,nAxis);
    for i = 1:nAxis
        matrixB(i,i) = (1/2)*(deltaT^2);
    end

    for i = nAxis+1:nAxis*2
        matrixB(i,i-nAxis) = deltaT;
    end

    %% Final equation to get the new state
    try
        xp=(matrixA*x)+(matrixB*u)+w;
    catch
        xp='';
       fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end