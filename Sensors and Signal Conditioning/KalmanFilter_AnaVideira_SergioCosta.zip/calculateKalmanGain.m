function kalmanGain = calculateKalmanGain(pkp,deltaErrorX,deltaErrorV)
    %% Build the matrix R
    matrixR = zeros(2);
    matrixR(1,1) = deltaErrorX^2;
    matrixR(2,2) = deltaErrorV^2;

    %% Build the matrix H
    matrixH = eye(2);

    %% Final equation
    try
        kalmanGain = (pkp*(matrixH.'))/((matrixH*pkp*(matrixH.'))+matrixR);
    catch
        kalmanGain='';
        fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end