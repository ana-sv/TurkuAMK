function covarianceMatrix = inicialProcessCovariance(deltaX, deltaV)    
    covarianceMatrix = zeros(2);
    covarianceMatrix(1,1) = deltaX^2;
    covarianceMatrix(2,2) = deltaV^2;
end