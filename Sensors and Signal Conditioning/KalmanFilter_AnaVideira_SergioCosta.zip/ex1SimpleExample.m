function [kg,est,error_est] = ex1SimpleExample(loops,mea,error_mea,inicial_estimate,error_estimate)
    kg = zeros(loops+1,1);
    est = zeros(loops+1,1);
    error_est = zeros(loops+1,1);
    
    est_aux = inicial_estimate;
    error_est_aux = error_estimate;
    est(1)=inicial_estimate;
    error_est(1)=error_estimate;
    
    for i = 1:loops
        kg_aux = ex1KalmanGain(error_est_aux,error_mea(i+1));
        est_aux = ex1CurrentEstimate(est_aux,kg_aux ,mea(i+1));
        error_est_aux = ex1ErrorEstimate(kg_aux ,error_est_aux);
    
        kg(i+1) = kg_aux;
        est(i+1) = est_aux;
        error_est(i+1) = error_est_aux;
    end
    table(mea,error_mea,kg,est,error_est)
end