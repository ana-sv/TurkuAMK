function average = ex4AverageOfMeasurements(mea)
    sum=0;
    for i = 0:length(mea)-1
        sum = sum + mea(i+1);
    end
    average = sum/length(mea);
end