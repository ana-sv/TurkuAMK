function currentEstimate = ex1CurrentEstimate(previousEstimate,kg,mea)
    currentEstimate = previousEstimate+kg*(mea-previousEstimate);
end