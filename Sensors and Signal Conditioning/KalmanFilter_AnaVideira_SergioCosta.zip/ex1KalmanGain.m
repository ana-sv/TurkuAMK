function kalmanGain = ex1KalmanGain(errorEstimate,errorMeasurement)
    kalmanGain = errorEstimate / (errorEstimate+errorMeasurement);
end