function newObservation = newObservation(matrixX,matrixZ)
    %% Build the matrix C
    matrixC = eye(height(matrixX));

    %% Final equation
    try
        newObservation = matrixC*matrixX+matrixZ;
    catch
        newObservation='';
        fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end