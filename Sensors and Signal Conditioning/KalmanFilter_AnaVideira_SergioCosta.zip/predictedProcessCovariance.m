function pkp = predictedProcessCovariance(nAxis,deltaT,pk,qk)
    %% Build the matrix A
    matrixA = eye(nAxis*2);
    for i = 1:width(matrixA)-nAxis
        matrixA(i,nAxis+i) = deltaT;
    end

    %% Final equation
    try
        pkp=matrixA*pk*(matrixA.')+qk;
        for i=1:length(pkp)
            for j=1:length(pkp)
                if(i~=j)
                    if(pkp(i,j)==pkp(j,i))
                        pkp(i,j)=0;
                        pkp(j,i)=0;
                    end
                end
            end
        end
    catch
        pkp='';
        fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end