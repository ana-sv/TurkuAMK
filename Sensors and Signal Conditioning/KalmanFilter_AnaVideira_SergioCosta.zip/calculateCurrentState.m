function currentState = calculateCurrentState(xkp,k,y)
    %% Build the matrix H
    matrixH = eye(height(xkp));

    %% Final equation
    try
        currentState = xkp+k*(y-matrixH*xkp);
    catch
        currentState='';
        fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end