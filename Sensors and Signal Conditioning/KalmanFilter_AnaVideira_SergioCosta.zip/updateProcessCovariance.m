function pk = updateProcessCovariance(matrixK,pkp)
    %% Build Matrix H and I
    matrixH = eye(height(matrixK));
    matrixI = eye(height(matrixK));

    %% Final equation
    try
        pk=(matrixI-matrixK*matrixH)*pkp;
    catch
        pk='';
        fprintf('<strong>ERROR: </strong>There is an error when doing the final equation!\nYou should gave valid values for the input!');
    end 
end