function covarianceMatrix = ex5CovarianceMatrix(measurements)
    average = zeros(1,width(measurements));
    for i = 1:width(measurements)
        average(i) = ex4AverageOfMeasurements(measurements(:,i));
    end
    
    covarianceMatrix = zeros(width(measurements));
    
    for i = 1:width(measurements)
        covarianceMatrix(i,i) = ex4VarianceCalculator(measurements(:,i),average(i));
    end
    
    sum12=0;
    sum31=0;
    sum32=0;
    for i = 1:height(measurements)
        multiply=(average(1)-measurements(i,1))*(average(2)-measurements(i,2));
        sum12 = sum12+multiply;
        multiply=(average(1)-measurements(i,1))*(average(3)-measurements(i,3));
        sum31 = sum31+multiply;
        multiply=(average(3)-measurements(i,3))*(average(2)-measurements(i,2));
        sum32 = sum32+multiply;
    end 
    covarianceMatrix(2,3)=sum32/length(measurements(:,2));
    covarianceMatrix(3,2)=sum32/length(measurements(:,2));
    
    covarianceMatrix(2,1)=sum12/length(measurements(:,2));
    covarianceMatrix(1,2)=sum12/length(measurements(:,2));
    
    covarianceMatrix(1,3)=sum31/length(measurements(:,1));
    covarianceMatrix(3,1)=sum31/length(measurements(:,1));
end