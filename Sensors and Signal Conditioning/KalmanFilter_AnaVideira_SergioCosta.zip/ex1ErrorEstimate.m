function errorEstimate = ex1ErrorEstimate(kg,previous_error)
    errorEstimate = (1-kg)*previous_error;
end