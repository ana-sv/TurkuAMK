#include <iostream>
#include <stdio.h>
#include <windows.h>
#include <algorithm>
#include <vector>

using namespace std;

double minTab(double* tab, int nbval) {
	double res = tab[0];
	for (int i = 0; i < nbval; i++)
		if (res > tab[i])
			res = tab[i];

	return res;
}

double maxTab(double* tab, int nbval) {
	double res = tab[0];
	for (int i = 0; i < nbval; i++)
		if (res < tab[i])
			res = tab[i];

	return res;
}


void shifAndAddTab(double* tab1, double* tab2, int nbValue1, int nbValue2) {
	//we shift all the array to get rid off the oldest values
	int i = 0;
	while (i < nbValue1 - nbValue2) {
		tab1[i] = tab1[nbValue2 + i];
		i++;
	}

	i = 0;

	//we add the new values at the end to keep a track with the previous ones
	for (int j = nbValue1 - nbValue2; j < nbValue1;j++) {
		tab1[j] = tab2[i];
		
		i++;
	}

}

void writeCSV(const char* filename, double* stream, int nbValues) {

	FILE* f = fopen(filename, "w");
	if (f == NULL) {
		printf_s("Error opening file, aborting\n");
		exit(1);
	}

	for (int i = 0; i < nbValues; i++) {
		fprintf_s(f, "%lf,\n", stream[i]);
	}

	fclose(f);
}


double* readCSV(const char* filename, int nbValues) {
	FILE* f;
	double* value = new double[nbValues];
	int i = 0;

	fopen_s(&f, filename, "r");
	if (f == NULL) {
		std::cout << "Error, unable to open the file!" << std::endl;
	}
	else {
		while (!feof(f)) {
			fscanf_s(f, "%lf,\n", &value[i]);
			i++;
		}
		fclose(f);
		return value;
	}

	return 0;
}


double getPeakThreshold(double* stream, int nbValue) {
	double Pthreshold;

	Pthreshold = maxTab(stream, nbValue);
	Pthreshold = Pthreshold / 2;

	return Pthreshold;
}


double getBPM(double * stream, int nbValue, double Pkthreshold) {

	int i = 0;
	bool PeakFound = false;
	double numOfPeak = 0;

	//Peak detection
	while (i < nbValue) {
		//if we are above the threshold that means we are in a peak
		if (stream[i] > Pkthreshold && !PeakFound) {

			//we are at the beginning of a peak, and we are looking for its end
			int startOfPeak = i;
			int endOfPeak = startOfPeak;

			//while I'm above the threshold, it means I'm inside the peak
			while ((stream[endOfPeak] > Pkthreshold) && (endOfPeak < nbValue-1)) {
				endOfPeak++;
			}

			//I found the peak so I increase the counter
			PeakFound = true;
			numOfPeak++;

			//I adjust 
			i = endOfPeak;
			
		}
		else {
			PeakFound = false;
		}
		i++;

	}

	//I divide the bumber of peak by the nuber of second we have sampled to get the number of Peak in 1 seconds, and then we multiply by 60 to get the bpm
	return (numOfPeak / ((double)nbValue /100))*60;

}





///////////////////////////////////////////////////// REVIEW
// For each sample take the 5 - 10 % highest values.
// Compare this measured values mean between a scale of rest - voltage and stressed - voltage.

double getHighAverage(double* stream, int nSamples) {    

	// double* to vector
	vector<double> streamVector(stream, stream + nSamples);

	for (unsigned int i = 0; i < streamVector.size(); i++)
		streamVector[i] = abs(streamVector[i]);
	
	// sorting in decending order
	sort(streamVector.begin(), streamVector.end(), greater<double>());

	// get the 10% higher peaks
	int nPeaks = 0.1 * nSamples;

	// average of the 10% higher peaks
	double sum = 0, averageValue = 0;

	for (int i = 0; i < nPeaks; i++) {
		sum += streamVector[i];
		//cout << streamVector[i] << " ";
	}
	averageValue = sum / nPeaks;

	return averageValue;
}


int labelingSample(double* sample, int nSamples, double stressThreshold) {

	double avg = getHighAverage(sample, nSamples);

	double static StressConstant = 0.7;

	if (avg >= StressConstant * stressThreshold) {
		//#ifdef DEBUG_MODE
		//cout << avg << " Stress " << endl;
		//#endif
		return 1;
	}
	else {
		//#ifdef DEBUG_MODE
		//cout << avg << " Relax " << endl;
		//#endif
		return 0; 
	}
	return -1; 
}








