#pragma once
#include <stdio.h>
#include <Windows.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include <sstream> 
#include <stdlib.h>

using namespace std;

void initFile(const char* filename, vector<INPUT>& vecInputECG, vector<INPUT>& vecInputEMG);

vector<INPUT> createReleaseVector(vector<INPUT> vecInput);