import pandas as pd
import matplotlib.pyplot as plt 

file_path = "./ECG.csv"
df = pd.read_csv(file_path)

for column in df.columns:
    print(df[column])
    plt.figure()
    plt.title(column)
    plt.plot(df[column])
    plt.show()