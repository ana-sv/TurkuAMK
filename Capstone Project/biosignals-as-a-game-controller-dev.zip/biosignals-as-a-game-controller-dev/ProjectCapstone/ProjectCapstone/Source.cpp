//#define CSV_MODE
#define DEBUG_MODE

#include <iostream>
#include <stdio.h>
#include <windows.h>
#include "utils.h"
#include "inputHandler.h"


#ifndef CSV_MODE
#include "mpdev.h"
#include "utilsMpdev.h"
MPRETURNCODE retval;
#endif 

//Numbers that deal with the amount of precision during real time acquisition
int PRECISION_DEGREE = 8;	//number of times the size of ECG array is bigger than the number of samples
int NUM_SAMPLES = 250;		//number of samples for all acquisition methods

using namespace std;
bool EMGOnlyMode = false;

//Aquire ECG channel 9  (slider on X)
//Aquire EMG channel 5 + 13 (slider on Y)
BOOL analogCH[] = {
false, false, false, false,
true, false, false, false,
true, false, false, false,
true, false, false, false };

double thresholdRelaxedCh1, thresholdRelaxedCh2,
thresholdStressedCh1, thresholdStressedCh2, thresholdECG, bpmECG;

vector<INPUT> ECGvec, EMGvec, ECGvecR, EMGvecR;


void getData(double * ECGchannelExtended);
void init(double* ECGchannelExtended);



int main(int argc, char ** argv){
	#ifndef CSV_MODE
	retval = connectMPDev(MP160, MPUDP, "auto");
	
	if (retval != MPSUCCESS)
	{
		cout << "Program failed to connect to MP Device" << endl;
		cout << "connectMPDev returned with " << retval << " as a return code." << endl;

		cout << "Disconnecting..." << endl;

		disconnectMPDev();

		cout << "Exit" << endl;

		return 0;
	}
	#endif // !CSV_MODE
	cout << "Initialising variables" << endl;

	//we create an array that will fit several set of samples so we can get better precision when calculating the bpm
	double* ECGchannelExtended = new double[PRECISION_DEGREE * NUM_SAMPLES];

	init(ECGchannelExtended);
	cout << "DONE!" << endl;

	cout << "Reading Data main loop" << endl;
	system("pause");
	getData(ECGchannelExtended);
	cout << "DONE!" << endl;

	cout << "Disconnecting..." << endl;
	
#ifndef CSV_MODE
	disconnectMPDev();
#endif

	cout << "Exit" << endl;

	delete[] ECGchannelExtended;
	return 0;
}

void init(double* ECGchannelExtended) {

	long numSamples = 1000;
	double* EMGchanneldata1 = new double[numSamples];
	double* EMGchanneldata2 = new double[numSamples];
	double* ECGchanneldata  = new double[numSamples*2];

	initFile("config.ini", ECGvec, EMGvec);
	ECGvecR = createReleaseVector(ECGvec);
	EMGvecR = createReleaseVector(EMGvec);

	cout << "Init file successful" << endl;

	EMGOnlyMode = ECGvec.empty() ? true : false;

	if (EMGOnlyMode) {
		PRECISION_DEGREE = 0;
		NUM_SAMPLES = 20;
	}


	#ifndef CSV_MODE
		retval = setAcqChannels(analogCH);

		if (retval != MPSUCCESS)
		{
			cout << "Program failed to set Acquisition Channels" << endl;
			cout << "setAcqChannels returned with " << retval << " as a return code." << endl;
			return;
		}

		//set sample rate to 10 msec per sample = 100 Hz
		retval = setSampleRate(10.0);

		if (retval != MPSUCCESS)
		{
			cout << "Program failed to set Sample Rate" << endl;
			cout << "setSampleRate returned with " << retval << " as a return code." << endl;
			return;
		}
		cout << "Remain calm for 10 seconds ..." << endl;
		system("pause");




		getDataMP160(numSamples, EMGchanneldata1, EMGchanneldata2, ECGchanneldata);
	#else
		numSamples = 1500;
		EMGchanneldata1 = readCSV("./CSV/EMG1AllRelax.csv", 1500);
		EMGchanneldata2 = readCSV("./CSV/EMG2AllRelax.csv", 1500);
		ECGchanneldata  = readCSV("./CSV/ECG.csv", 3000);
	#endif 
	

	thresholdRelaxedCh1 = getPeakThreshold(EMGchanneldata1, numSamples);
	thresholdRelaxedCh2 = getPeakThreshold(EMGchanneldata2, numSamples);

	#ifndef CSV_MODE
		cout << "Stress muscles for 10 seconds ..." << endl;
		system("pause");
		getDataMP160(numSamples, EMGchanneldata1, EMGchanneldata2, &ECGchanneldata[numSamples]);
	#else
		EMGchanneldata1 = readCSV("./CSV/EMG1AllStressed.csv", 1500);
		EMGchanneldata2 = readCSV("./CSV/EMG2AllStressed.csv", 1500);
	#endif 


	thresholdStressedCh1 = getPeakThreshold(EMGchanneldata1, numSamples);
	thresholdStressedCh2 = getPeakThreshold(EMGchanneldata2, numSamples);
	thresholdECG = getPeakThreshold(ECGchanneldata, numSamples);
	bpmECG = getBPM(ECGchanneldata,numSamples*2, thresholdECG);

	#ifdef DEBUG_MODE
		cout << "Peak relax on channel 1 : " << thresholdRelaxedCh1 << "\t\t Peak stress on channel 1 : " << thresholdStressedCh1 << endl;
		cout << "Peak relax on channel 2 : " << thresholdRelaxedCh2 << "\t\t Peak stress on channel 2 : " << thresholdStressedCh2 << endl;
		cout << "Peak relax on ECG : " << thresholdECG << endl;
		cout << "BPM relax on ECG : " << bpmECG << endl;
	#endif



	//we fill the Extended array in order to get a bigger array and thus more precision in real time acquisition of ECG
	for (int i = 0;i < PRECISION_DEGREE * NUM_SAMPLES;i++) {
		ECGchannelExtended[i] = ECGchanneldata[i % numSamples];
	}

	delete[] EMGchanneldata1;
	delete[] EMGchanneldata2;
	delete[] ECGchanneldata;
}

void getData(double* ECGchannelExtended) {
	
	long numSamplesECG = NUM_SAMPLES * PRECISION_DEGREE;

	double* EMGchanneldata1 = new double[NUM_SAMPLES];
	double* EMGchanneldata2 = new double[NUM_SAMPLES];
	double* ECGchanneldata  = new double[NUM_SAMPLES];

	double bpm = 60;
	int stress1, stress2;

	#ifndef CSV_MODE
	while (true)
	{
		getDataMP160(NUM_SAMPLES, EMGchanneldata1, EMGchanneldata2, ECGchanneldata);
		shifAndAddTab(ECGchannelExtended, ECGchanneldata, numSamplesECG, NUM_SAMPLES);
		bpm = getBPM(ECGchannelExtended, numSamplesECG, thresholdECG);
		stress1 = labelingSample(EMGchanneldata1, NUM_SAMPLES, thresholdStressedCh1);
		stress2 = labelingSample(EMGchanneldata2, NUM_SAMPLES, thresholdStressedCh2);

		system("cls");

		if(EMGOnlyMode)
			printf("Not in ECG mode\n");
		else
			printf("Current BPM : %2.0lf\nThershold BPM : %2.0lf\n", bpm, bpmECG * 1.4);

		printf("Stressed1 : %d\tStressed2 : %d\t\n", stress1, stress2);

		if (stress1 and stress2) {
			SendInput(EMGvec.size(), EMGvec.data(), sizeof(INPUT));
		}
		else {
			SendInput(EMGvecR.size(), EMGvecR.data(), sizeof(INPUT));
		}

		if(not EMGOnlyMode and bpm > bpmECG * 1.4) {
			SendInput(ECGvec.size(), ECGvec.data(), sizeof(INPUT));
		}
		else {
			SendInput(ECGvecR.size(), ECGvecR.data(), sizeof(INPUT));
		}

	}
	#endif // !CSV_MODE

	delete[] EMGchanneldata1;
	delete[] EMGchanneldata2;
	delete[] ECGchanneldata;
	delete[] ECGchannelExtended;

}