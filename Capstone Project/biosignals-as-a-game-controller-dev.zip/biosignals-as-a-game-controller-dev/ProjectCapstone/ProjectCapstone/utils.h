#pragma once

/// <summary>
/// Function that return the minimum in an array of double.
/// </summary>
/// <param name="tab">The adress of the array</param>
/// <param name="nbval">The number of value in the array</param>
/// <returns>The lowest value in the array</returns>
double minTab(double* tab, int nbval);

/// <summary>
/// Function that return the maximum in an array of double.
/// </summary>
/// <param name="tab">The adress of the array</param>
/// <param name="nbval">The number of value in the array</param>
/// <returns>The highest value in the array</returns>
double maxTab(double* tab, int nbval);

/**
* @brief shift to the left tab1 by the number of value of tab2 and insert tab2 at then end of tab1
* 
* @param [inout] tab1 array to be modified
* @param [in] tab2 array to be added to tab2
* @param [in] nbValue1 number of value in tab1
* @param [in] nbValue2 number of value in tab2
*/
void shifAndAddTab(double* tab1, double* tab2, int nbValue1, int nbValue2);

/// <summary>
/// A function that write a double array in a CSV file
/// </summary>
/// <param name="filename">The output file name</param>
/// <param name="stream">The double array</param>
/// <param name="nbValues">The number of value of the double array</param>
void writeCSV(const char* filename, double* stream, int nbValues);


/// <summary>
/// A function that reads a CSV file and write it to a double array
/// </summary>
/// <param name="filename">The input CSV file</param>
/// <param name="nbValues">The number of values in the CSV file</param>
/// <returns>The output double array</returns>
double* readCSV(const char* filename, int nbValues);

/**
* @brief Gives the value based on the highest peak of the samples
*
* @param [in] stream Our incoming ECG values
* @param [in] nbValue number of value in stream
*/
double getPeakThreshold(double* stream, int nbValue);

/**
* @brief Gives the bpm out of a stream of data
* 
* @param [in] stream Our incoming ECG values
* @param [in] nbValue Number of value in stream
*/
double getBPM(double* stream, int nbValue, double Pkthreshold);

/**
* @brief  Gives the averageValue based on the highest peak of the EMG samples
*
* 
*/
double getHighAverage(double* stream, int nSamples);

int labelingSample(double* sample, int nSamples, double stressThreshold);