#include <stdio.h>
#include <Windows.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include <sstream> 
#include <stdlib.h>



using namespace std;

map<string, int> keys2code{
    {"ESC",1},
    {"1",2},
    {"2",3},
    {"3",4},
    {"4",5},
    {"5",6},
    {"6",7},
    {"7",8},
    {"8",9},
    {"9",10},
    {"0",11},
    {"-",12},
    {"=",13},
    {"Backspace",14},
    {"Tab",15},
    {"Q",16},
    {"W",17},
    {"E",18},
    {"R",19},
    {"T",20},
    {"Y",21},
    {"U",22},
    {"I",23},
    {"O",24},
    {"P",25},
    {"[",26},
    {"]",27},
    {"Enter",28},
    {"CTRL",29},
    {"A",30},
    {"S",31},
    {"D",32},
    {"F",33},
    {"G",34},
    {"H",35},
    {"J",36},
    {"K",37},
    {"L",38},
    {";",39},
    {"'",40},
    {"`",41},
    {"LShift",42},
    {"\\",43},
    {"Z",44},
    {"X",45},
    {"C",46},
    {"V",47},
    {"B",48},
    {"N",49},
    {"M",50},
    {",",51},
    {".",52},
    {"/",53},
    {"RShift",54},
    {"PrtSc",55},
    {"Alt",56},
    {"Space",57},
    {"Caps",58},
    {"F1",59},
    {"F2",60},
    {"F3",61},
    {"F4",62},
    {"F5",63},
    {"F6",64},
    {"F7",65},
    {"F8",66},
    {"F9",67},
    {"F10",68},
    {"Num",69},
    {"Scroll",70},
    {"Home",71},
    {"Up",72},
    {"PgUp",73},
    {"-Num",74},
    {"Left",75},
    {"Center",76},
    {"Right",77},
    {"+Num",78},
    {"End",79},
    {"Down",80},
    {"PgDn",81},
    {"Ins",82},
    {"Del",83},
    {"F11",133},
    {"F12",134},
};

map<string, DWORD> mouse2code{
    {"M_LEFT", MOUSEEVENTF_LEFTDOWN},
    {"M_RIGHT", MOUSEEVENTF_RIGHTDOWN},
    {"M_MIDDLE", MOUSEEVENTF_MIDDLEDOWN}
};


void initFile(const char* filename, vector<INPUT>& vecInputECG, vector<INPUT>& vecInputEMG) {

    string ECGconf, EMGconf, w;
    ifstream file;
    vector<int> vecEMG, vecECG;
    vector<DWORD> vecMouseEMG, vecMouseECG;

    file.open(filename);
    if (!file.is_open()) {
        cout << "Failed to open file... Exiting" << endl;
        exit(-1);
    }

    //We get the first line of the config file
    getline(file, ECGconf);

    //We erase the "ECG: " part to get only the keys we want to press
    ECGconf.erase(0, 5);

    //We 'translate' the keys to hardware scan code using our dictionnary.
    stringstream ss(ECGconf);
    while (ss >> w) {
        if (keys2code[w] != 0)
            vecECG.push_back(keys2code[w]);
        else if (mouse2code[w] != NULL)
            vecMouseECG.push_back(mouse2code[w]);
        else {
            cout << "ECG : Could not understant following parameter: " << w << endl << " Abort" << endl;
            exit(-1);
        }

    }


    //We remove the empty line in the config file between ECG and EMG
    getline(file, EMGconf);

    //We repeat the same operation we did for ECG
    getline(file, EMGconf);
    EMGconf.erase(0, 5);
    stringstream ss2(EMGconf);
    while (ss2 >> w) {
        if (keys2code[w] != 0)
            vecEMG.push_back(keys2code[w]);
        else if (mouse2code[w] != NULL)
            vecMouseEMG.push_back(mouse2code[w]);
        else {
            cout << "EMG : Could not understant following parameter: " << w << endl << " Abort" << endl;
            exit(-1);
        }
    }


    for (int i : vecECG) {
        INPUT ip;
        ZeroMemory(&ip, sizeof(ip));

        ip.type = INPUT_KEYBOARD;
        ip.ki.wScan = i;
        ip.ki.dwFlags = KEYEVENTF_SCANCODE;

        vecInputECG.push_back(ip);
    }

    for (DWORD w : vecMouseECG) {
        INPUT ip;
        ZeroMemory(&ip, sizeof(ip));
        ip.type = INPUT_MOUSE;
        ip.mi.dwFlags = w;


        vecInputECG.push_back(ip);
    }




    for (int i : vecEMG) {
        INPUT ip;
        ZeroMemory(&ip, sizeof(ip));

        ip.type = INPUT_KEYBOARD;
        ip.ki.wScan = i;
        ip.ki.dwFlags = KEYEVENTF_SCANCODE;

        vecInputEMG.push_back(ip);
    }

    for (DWORD w : vecMouseEMG) {
        INPUT ip;
        ZeroMemory(&ip, sizeof(ip));
        ip.type = INPUT_MOUSE;
        ip.mi.dwFlags = w;


        vecInputEMG.push_back(ip);
    }



}

vector<INPUT> createReleaseVector(vector<INPUT> vecInput) {

    vector<INPUT> res;

    for (INPUT i : vecInput) {
        if (i.type == INPUT_KEYBOARD)
            i.ki.dwFlags |= KEYEVENTF_KEYUP;
        else if (i.type == INPUT_MOUSE && i.mi.dwFlags != MOUSEEVENTF_MIDDLEDOWN)
            i.mi.dwFlags += 2;
        else if (i.type == INPUT_MOUSE && i.mi.dwFlags == MOUSEEVENTF_MIDDLEDOWN)
            i.mi.dwFlags += 20;


        res.push_back(i);
    }

    return res;

}
