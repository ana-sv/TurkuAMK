#pragma once


/**
* @brief Function that return the lasted mesurement of the MP160 on the different channels 
* 
* @param [in] numsample The number of sample for EACH data channel
* 
* @param [out] EMGchan1 Data from the EMG channel 1 from the MP160
* @param [out] EMGchan2 Data from the EMG channel 2 from the MP160
* @param [out] ECGchan Data from the ECG channel from the MP160
*/
void getDataMP160(int numsamples, double* EMGchan1, double* EMGchan2, double* ECGchan);