#include <iostream>
#include <stdio.h>

#include "utils.h"
#include "utilsMpdev.h"
#include "mpdev.h"

using namespace std;


void getDataMP160(int numsamples, double* EMGchan1, double* EMGchan2, double* ECGchan){

	double* data = new double[3 * numsamples];

	MPRETURNCODE retval = startAcquisition();
	if (retval != MPSUCCESS)
	{
		cout << "Program failed to Start Acquisition" << endl;
		cout << "startAcquisition returned with " << retval << " as a return code." << endl;

		cout << "Stopping..." << endl;

		stopAcquisition();

		return;
	}

	retval = getMPBuffer(numsamples, data);

	if (retval != MPSUCCESS)
	{
		cout << "Program failed to get data" << endl;
		cout << "getMPBuffer(...) returned with " << retval << " as a return code." << endl;

		cout << "Stopping..." << endl;

		stopAcquisition();

		return;
	}

	int smallIndex = 0;

	for (int i = 0; i < numsamples * 3; i++) {
		if (i % 3 == 0) {
			EMGchan1[smallIndex] = data[i];
		}
		else if (i % 3 == 1) {
			ECGchan[smallIndex] = data[i];
		}
		else {
			EMGchan2[smallIndex] = data[i];
			smallIndex++;
		}
	}

	delete[] data;

}
