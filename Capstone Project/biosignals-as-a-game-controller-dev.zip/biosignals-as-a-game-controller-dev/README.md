# Biosignals as a game controller


## Description
Utilising a Biopac MP160 - and it's API, albeit very limited and poorly documented - to unlock it's sensor-data for use with 3rd-party software.
Data gathered from the Biopac is used as an input for a game controller and be able to use it to play games (e.g. Minecraft). This provides a working application that is capable of translating data such as heart-beat rate (ECG) and muscle compression (EMG) into clear controller-inputs using Biopac API. 

## Authors and acknowledgment
* Elouan Rigaut
* Viktor Rehor
* Jooa Jaakkola
* Ana Videira
* Jon Carne
* Aleksi Järvimäki
* Ehsan Akbari



# config.ini Configuration

**/!\ PLEASE BE CAREFUL THE ```config.ini``` FILE FOLLOWS THIS EXACT SYNTAX:**

```
ECG: [Your token(s) separated by a space]

EMG: [Your token(s) separated by a space]
```

**/!\ The token(s) can be empty, but be careful to still have a ' ' after the ':' on both ECG and EMG /!\\**

## Keyboard tokens

**/!\ If you configure keys, make sure you do it using key placement on a STRANDARD US-QWERTY KEYBOARD the OS will then translate the keys to give the right character using your set keyboard layout /!\\**

* ESC
* 1-0
* A-Z
* F1-F12
* ESC
* \-
* =
* Backspace
* tab
* [
* ]
* Enter
* CTRL
* ;
* '
* `
* LShift
* RShift
* \
* ,
* .
* /
* PrtSc
* Alt
* Space
* Caps
* Num
* Scroll
* Home
* Up
* PgUp
* Left
* -Num
* Left
* Center
* Right
* +Num
* End
* Down
* PgDn
* Ins
* Del

## Mouse tokens

* M_LEFT
* M_RIGHT
* M_MIDDLE