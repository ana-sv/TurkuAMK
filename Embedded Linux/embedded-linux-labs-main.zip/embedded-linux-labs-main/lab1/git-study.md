# Lab assignment 1

### Q1: What are the benefits of using git version control?

The ability to provide an organized history of the content changes made and who made those changes . Facilitates collaboratives changes to files and is easy to use for any type of knowledge worker. 

&nbsp;

### Q2: What is a distributed version control system?

Distributed version control helps teams to create and maintain strong workflows and hierarchies, with each person making changes to their own repository  and maintainers reviewing those changes to ensure only quality work merges in to the main repository.

&nbsp;

### Q3: What are the most important git commands in terminal use?

git config → for configuring git 

git init project1 → creates  a directory for project1 

git add file1.txt → add file to version control, still not permanently just signalling it 

git commit -m “ CommitMessage”  → add permanently the files that were signalize by the previous add command 

&nbsp;
&nbsp;

# Lab assignment 2

### Q4: Explain "GitLab Recommended Process"

By the Gitlab recommended Process a production line of code should start with **creating an issue.** The issue is discussed with the team and when it’s gets to the point that the developer is ready to start working on it, the developer can create a merge request directly from the issue.


**The merge request** is the place were the developer will be doing a lot of the work, creating commits as changes are made . Creating a merge request from the issue will automatically create a feature branch , ,isolated from the mainline branch, and creating in the beginning will allow the capture of all changes and activities in one place.

Next, the changes are pushed back in to the server, the CI pipeline if can be configured to run witch generally will build and test the code and gave those results directly with the merge request. Another thing that be done in this phase is a security scan and reviews or a temporary deploy out to a temporary review app.

After the **changes are approved** and **the branch is merged back in to the mainline branch.**

&nbsp;


### Q5: What is a "Merge Request"?

Merge request is the way to check the source code changes into a branch. A merge request includes: a description of the request, code changes and inline code reviews, information about CI/CD pipelines , a comment section for the discussion threads and a list of commits.

&nbsp;
&nbsp;

# Reflection: 
#### In embedded application, why would you write application output to a file instead of just printf it to terminal?

In embedded applications, writing the application output to a file instead of simply printing it to the terminal can be a useful practice. This approach provides a more systematic and organized way of recording the application's behavior and performance, making it easier to track changes and identify issues. Additionally, when dealing with large amounts of output, writing it to a file can be more efficient than printing it to the terminal, particularly when dealing with resource-constrained systems. The output file can also be helpful in debugging, providing valuable information to help diagnose problems and identify potential solutions. Overall, writing application output to a file can enhance the performance, scalability, and maintainability of embedded systems.
