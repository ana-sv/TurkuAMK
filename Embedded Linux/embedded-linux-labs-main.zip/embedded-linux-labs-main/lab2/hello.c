#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int main() {
  char msg[1000] = "Hi there ! ";

  time_t t;
  time(&t);

  FILE *fptr;

  // opening file in writing mode
  fptr = fopen("messageFile.txt", "a");

  // exiting program
  if (fptr == NULL) {
    printf("Error!");
    exit(1);
  }

  strcat(msg, ctime(&t));
  
  printf("%s", msg); 

  fprintf(fptr, "%s", msg);

  if (fclose(fptr) != 0 ){
    printf("Error closing file! ");
    exit(1);
  }

  return 0;
}
