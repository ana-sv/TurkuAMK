# Documentation for hello.c

This program generates a message and saves it to a file. The message consists of a greeting and the current date and time.

## Dependencies
The following header files are required for this program to run:
- `stdio.h`
- `stdlib.h`
- `time.h`
- `string.h`

## Functions
### `main()`
The `main` function is responsible for generating the message and saving it to a file. It has the following steps:
1. Declare a character array `msg` of size 1000 and initialize it with "Hi there! ".
2. Get the current time using `time(&t)`, where `t` is a variable of type `time_t`.
3. Open a file named `messageFile.txt` in append mode using `fopen()`. If the file fails to open, print an error message using `printf()` and exit the program using `exit(1)`.
4. Append the current time to the message string `msg` using `strcat()`.
5. Print the message to the console using `printf()`.
6. Write the message to the file using `fprintf()`.
7. Close the file using `fclose()`. If the file fails to close, print an error message using `printf()` and exit the program using `exit(1)`.
8. Return 0 to indicate that the program has executed successfully.

## Usage
1. Compile the program using a C compiler.
2. Run the program.
3. The program will generate a message and save it to a file named `messageFile.txt` in the current directory.
