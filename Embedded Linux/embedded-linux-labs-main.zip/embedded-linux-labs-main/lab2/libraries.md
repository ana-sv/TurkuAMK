# Lab assignment

## Reflection: What are the benefits of shared libraries? 
- Less disk space is used because the shared library code is not included in the executable programs.
- Less memory is used because the shared library code is only loaded once.
- Load time may be reduced because the shared library code may already be in memory.
- Performance may be improved because fewer page faults will be generated when the shared library code is already in memory.However, there is a performance cost in calls to shared library routines of one to eight instructions.

<br>

## Where is the executable located (file path) in VM and in raspi?

In the raspi the executable file is located in home/pi.
<br>
In the VM is located in /h/home/student/embedded-linux-labs/lab2

<br>

## Use file command. Check for what architecture the executable was built for. 

```
student@student-VirtualBox:~/embedded-linux-labs/lab2$ file hello
hello: ELF 64-bit LSB shared object, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=98548ebacbdabe44c7e4b9238528bad7b6e4b60b, for GNU/Linux 3.2.0, not stripped
```

```
i@easyname:~ $ file hello
hello: ELF 32-bit LSB executable, ARM, EABI5 version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux-armhf.so.3, for GNU/Linux 3.2.0, with debug_info, not stripped
```

<br>

## Use ldd command. Find out what shared runtime libraries your executable requires. 

```
student@student-VirtualBox:~/embedded-linux-labs/lab2$ ldd hello
	linux-vdso.so.1 (0x00007ffc7b3e3000)
	libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007f4899a33000)
	/lib64/ld-linux-x86-64.so.2 (0x00007f4899c3e000)

```


```
pi@easyname:~ $ ldd hello
	linux-vdso.so.1 (0xbec81000)
	/usr/lib/arm-linux-gnueabihf/libarmmem-${PLATFORM}.so => /usr/lib/arm-linux-gnueabihf/libarmmem-v7l.so (0xb6f68000)
	libc.so.6 => /lib/arm-linux-gnueabihf/libc.so.6 (0xb6dff000)
	/lib/ld-linux-armhf.so.3 (0xb6f7d000)

```

<br>



## Find all files named libc.so.6 in both systems VM and raspi (use find command)

In VM :

```
student@student-VirtualBox:~$ sudo find / -name libc.so.6
/usr/lib/x86_64-linux-gnu/libc.so.6
/usr/libx32/libc.so.6
/usr/lib32/libc.so.6
/usr/aarch64-linux-gnu/lib/libc.so.6
find: ‘/run/user/1000/doc’: Permission denied
find: ‘/run/user/1000/gvfs’: Permission denied
/var/lib/schroot/chroots/rpizero-bullseye-armhf/usr/lib/arm-linux-gnueabihf/libc.so.6
/var/lib/schroot/chroots/rpizero-buster-armhf/usr/lib/arm-linux-gnueabihf/libc.so.6
/home/student/opt/x-tools/aarch64-rpi3-linux-gnu/aarch64-rpi3-linux-gnu/sysroot/lib/libc.so.6
/home/student/opt/x-tools/armv6-rpi-linux-gnueabihf/armv6-rpi-linux-gnueabihf/sysroot/lib/libc.so.6
/snap/snapd/18357/lib/x86_64-linux-gnu/libc.so.6
/snap/snapd/17950/lib/x86_64-linux-gnu/libc.so.6
/snap/core20/1822/usr/lib/i386-linux-gnu/libc.so.6
/snap/core20/1822/usr/lib/x86_64-linux-gnu/libc.so.6
/snap/core20/1778/usr/lib/i386-linux-gnu/libc.so.6
/snap/core20/1778/usr/lib/x86_64-linux-gnu/libc.so.6
```

In Raspi:

```
pi@easyname:~ $ sudo find / -name libc.so.6
/usr/lib/arm-linux-gnueabihf/libc.so.6
```
<br>

## For each library, the key information :


- file path: /usr/lib/x86_64-linux-gnu/libc.so.6
```
student@student-VirtualBox:~$ file /usr/lib/x86_64-linux-gnu/libc.so.6
/usr/lib/x86_64-linux-gnu/libc.so.6: symbolic link to libc-2.31.so
```
- symbolic link : /usr/lib/x86_64-linux-gnu/libc-2.31.so
- file path in the symbolic link :
/usr/lib/x86_64-linux-gnu/libc-2.31.so: ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=1878e6b475720c7c51969e69ab2d276fae6d1dee, for GNU/Linux 3.2.0, stripped
- library architecture: x86_64
- library version: GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.


<br>

- /usr/libx32/libc.so.6
- /usr/libx32/libc-2.31.so
- /usr/libx32/libc-2.31.so: ELF 32-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /libx32/ld-linux-x32.so.2, BuildID[sha1]=638ad4d5c0b6028fe93bec508021232ab130ff06, for GNU/Linux 3.4.0, stripped
- GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.



<br>

- /usr/libx32/libc.so.6
- /usr/libx32/libc-2.31.so
- /usr/libx32/libc-2.31.so: ELF 32-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /libx32/ld-linux-x32.so.2, BuildID[sha1]=638ad4d5c0b6028fe93bec508021232ab130ff06, for GNU/Linux 3.4.0, stripped
- GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.



<br>

- /usr/lib32/libc.so.6
- /usr/lib32/libc-2.31.so
- /usr/lib32/libc-2.31.so: ELF 32-bit LSB shared object, Intel 80386, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux.so.2, BuildID[sha1]=8c11d7b4ac6d685f0bba1cf2506a80f64d314582, for GNU/Linux 3.2.0, stripped
- NU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.


<br>


- /usr/aarch64-linux-gnu/lib/libc.so.6
- /usr/aarch64-linux-gnu/lib/libc-2.31.so
- /usr/aarch64-linux-gnu/lib/libc-2.31.so: ELF 64-bit LSB shared object, ARM aarch64, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux-aarch64.so.1, BuildID[sha1]=da58e6db1e82f6b1ea74389987b8eaa4cddc34b4, for GNU/Linux 3.7.0, stripped
- GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.


<br>


- /var/lib/schroot/chroots/rpizero-bullseye-armhf/usr/lib/arm-linux-gnueabihf/libc.so.6
- /var/lib/schroot/chroots/rpizero-bullseye-armhf/usr/lib/arm-linux-gnueabihf/libc-2.31.so
- /var/lib/schroot/chroots/rpizero-bullseye-armhf/usr/lib/arm-linux-gnueabihf/libc-2.31.so: ELF 32-bit LSB shared object, ARM, EABI5 version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux-armhf.so.3, BuildID[sha1]=6a96171315badd539d8d2f2125bbf048c4dcd545, for GNU/Linux 3.2.0, stripped
- GNU C Library (Debian GLIBC 2.31-13+rpt2+rpi1+deb11u5) stable release version 2.31. Compiled by GNU CC version 10.2.1 20210110.


<br>


- /var/lib/schroot/chroots/rpizero-buster-armhf/usr/lib/arm-linux-gnueabihf/libc.so.6
- var/lib/schroot/chroots/rpizero-buster-armhf/usr/lib/arm-linux-gnueabihf/libc-2.28.so
- /var/lib/schroot/chroots/rpizero-buster-armhf/usr/lib/arm-linux-gnueabihf/libc-2.28.so: ELF 32-bit LSB shared object, ARM, EABI5 version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux-armhf.so.3,
- BuildID[sha1]=f7717f6599efad3a550ba2c3b42e0697cac4c3e8, for GNU/Linux 3.2.0, stripped
- GNU C Library (Debian GLIBC 2.28-10+rpi1+deb10u2) stable release version 2.28. Compiled by GNU CC version 8.3.0.


<br>


- /home/student/opt/x-tools/aarch64-rpi3-linux-gnu/aarch64-rpi3-linux-gnu/sysroot/lib/libc.so.6
- /home/student/opt/x-tools/aarch64-rpi3-linux-gnu/aarch64-rpi3-linux-gnu/sysroot/lib/libc-2.28.so
- home/student/opt/x-tools/aarch64-rpi3-linux-gnu/aarch64-rpi3-linux-gnu/sysroot/lib/libc-2.28.so: ELF 64-bit LSB shared object, ARM aarch64, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux-aarch64.so.1, for GNU/Linux 5.8.18, with debug_info, not stripped
-  GNU C Library (crosstool-NG UNKNOWN) stable release version 2.28.
- Compiled by GNU CC version 12.1.0.


<br>


- /home/student/opt/x-tools/armv6-rpi-linux-gnueabihf/armv6-rpi-linux-gnueabihf/sysroot/lib/libc.so.6
- /home/student/opt/x-tools/armv6-rpi-linux-gnueabihf/armv6-rpi-linux-gnueabihf/sysroot/lib/libc-2.28.so
- /home/student/opt/x-tools/armv6-rpi-linux-gnueabihf/armv6-rpi-linux-gnueabihf/sysroot/lib/libc-2.28.so: ELF 32-bit LSB shared object, ARM, EABI5 version 1 (SYSV), dynamically linked, interpreter /lib/ld-linux-armhf.so.3, for GNU/Linux 5.8.18, with debug_info, not stripped
- o GNU C Library (crosstool-NG UNKNOWN) stable release version 2.28.
- Compiled by GNU CC version 12.1.0.


<br>


- /snap/core/14447/lib/i386-linux-gnu/libc.so.6
-  snap/core/14447/lib/i386-linux-gnu/libc-2.23.so
- /snap/core/14447/lib/i386-linux-gnu/libc-2.23.so/snap/core/14447/lib/i386-linux-gnu/libc-2.23.so: ELF 32-bit LSB shared object, Intel 80386, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux.so.2, BuildID[sha1]=b5f2a84bddf05837cbf4064ef6ddb4b53d005398, for GNU/Linux 2.6.32, stripped
- GNU C Library (Ubuntu GLIBC 2.23-0ubuntu11.3+esm2) stable release version 2.23, by Roland McGrath et al

<br>


-  /snap/core/14447/lib/x86_64-linux-gnu/libc.so.6
-  /snap/core/14447/lib/x86_64-linux-gnu/libc-2.23.so
- /snap/core/14447/lib/x86_64-linux-gnu/libc-2.23.so: ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=e27f7d2c72cf38199e427cfc5988b35903b42df2, for GNU/Linux 2.6.32, stripped
-  GNU C Library (Ubuntu GLIBC 2.23-0ubuntu11.3+esm2) stable release version 2.23, by Roland McGrath et al.

<br>

- /snap/snapd/17950/lib/x86_64-linux-gnu/libc.so.6
- /snap/snapd/17950/lib/x86_64-linux-gnu/libc-2.23.so
- /snap/snapd/17950/lib/x86_64-linux-gnu/libc-2.23.so: ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2,
- BuildID[sha1]=e27f7d2c72cf38199e427cfc5988b35903b42df2, for GNU/Linux 2.6.32, stripped
-  GNU C Library (Ubuntu GLIBC 2.23-0ubuntu11.3+esm2) stable release version 2.23, by Roland McGrath et al.

<br>

- /snap/core20/1695/usr/lib/i386-linux-gnu/libc.so.6
-  /snap/core20/1695/usr/lib/i386-linux-gnu/libc-2.31.so
-  /snap/core20/1695/usr/lib/i386-linux-gnu/libc-2.31.so: ELF 32-bit LSB shared object, Intel 80386, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux.so.2, BuildID[sha1]=df8f1e9a9f0a04861cfd9f7e4d3ae4bf19c0859a, for GNU/Linux 3.2.0, stripped
-  GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31.
- Compiled by GNU CC version 9.4.0.


<br>

-  /snap/core20/1695/usr/lib/x86_64-linux-gnu/libc.so.6
-  /snap/core20/1695/usr/lib/x86_64-linux-gnu/libc-2.31.so
-  /snap/core20/1695/usr/lib/x86_64-linux-gnu/libc-2.31.so: ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=1878e6b475720c7c51969e69ab2d276fae6d1dee, for GNU/Linux 3.2.0, stripped
-  GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31.
- Compiled by GNU CC version 9.4.0.


<br>

-  /snap/core20/1778/usr/lib/i386-linux-gnu/libc.so.6
-  /snap/core20/1778/usr/lib/i386-linux-gnu/libc-2.31.so
-  /snap/core20/1778/usr/lib/i386-linux-gnu/libc-2.31.so: ELF 32-bit LSB shared object, Intel 80386, version 1 (GNU/Linux), dynamically linked, interpreter /lib/ld-linux.so.2, BuildID[sha1]=df8f1e9a9f0a04861cfd9f7e4d3ae4bf19c0859a, for GNU/Linux 3.2.0, stripped
-  GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31.
- Compiled by GNU CC version 9.4.0.


<br>

- /snap/core20/1778/usr/lib/x86_64-linux-gnu/libc.so.6
-  /snap/core20/1778/usr/lib/x86_64-linux-gnu/libc-2.31.so
-  /snap/core20/1778/usr/lib/x86_64-linux-gnu/libc-2.31.so: ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked, interpreter /lib64/ld-linux-x86-64.so.2, BuildID[sha1]=1878e6b475720c7c51969e69ab2d276fae6d1dee, for GNU/Linux 3.2.0, stripped
-  GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9)





<br>

## Identify (file path and version) the three libraries in cross-development diagram presented :

- Build-time library and Debug library (in VM) : 

	- path : /usr/lib/arm-linux-gnueabihf/libc.so.6 
	- version :  GNU C Library (Ubuntu GLIBC 2.31-0ubuntu9.9) stable release version 2.31. Compiled by GNU CC version 9.4.0.
	```

	```



  
- Run-time library (in raspi)
  
	- path :  /usr/lib/arm-linux-gnueabihf/libc.so.6
	- version : GNU C Library (Debian GLIBC 2.31-13+rpt2+rpi1+deb11u5) stable release version 2.31.

  
  <br>

## Glibc library is downwards compatible. Can you be sure that executables built on this setup and target Debian Bullseye will run on
- Debian Bookworm (glibc version 2.36)? 
There will be compatibility issues because Debian Bookworm uses a more recent version os glibc library.

- Debian Buster (glibc version 2.28)? 
Yes, because Debian Buster uses an older version of the glibc library than the Debian Bullseye

<br>

## What do you need to do with development setup, if you

- upgrade the target to Debian Bookworm? 
Update the development setup to ensure compatibility with the new operating system version. This involves updating packages to their latest versions, checking for compatibility of development tools and libraries, and installing any necessary updates or replacements to ensure they work properly.


- downgrade the target to Debian Buster?
Downgrade your development setup, packages and configurations that were updated or changed. This can involve rolling back packages to previous versions, resetting configurations to their previous state, and ensuring that any new packages installed during the upgrade are removed. Additionally, checking for compatibility issues with development tools and libraries to ensure they work properly with the older version of the operating system.

<br>

# Reflection: What are benefits of cross-development setup?
One of the key benefits is the ability to develop and test software on one platform, and then deploy it to another platform. This is especially useful when developing software for embedded systems or other devices with limited resources, as it allows developers to write and test code on a more powerful machine before deploying it to the target device. Cross-development also allows for more efficient development and testing, as developers can work on a single machine rather than having to switch between multiple devices. Finally, cross-development can help reduce costs by allowing developers to use cheaper, more widely available hardware for development, rather than requiring dedicated hardware for each target platform.

<br>
