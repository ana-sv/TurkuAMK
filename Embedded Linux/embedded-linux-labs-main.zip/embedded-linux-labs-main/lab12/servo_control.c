#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/pwm.h>
#include <linux/gpio.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple PWM kernel module");
MODULE_VERSION("0.1");

static struct pwm_device *pwm_dev;
static struct hrtimer pwm_timer;

static int array[] = {0, 10000, 32500, 75000, 140000, 232500, 355000, 507500, 675000, 875500, 1047500, 1242500, 1440000, 1630000, 1812500, 1980000, 2130000, 2325000, 2357500, 2425000, 2465000, 2490000, 2500000};
static unsigned int counter = 0;
static bool comprobator = true;

static enum hrtimer_restart pwm_timer_callback(struct hrtimer *timer) {
    ktime_t now = timer->base->get_time();
    int pwm_value;

    if (comprobator) {
        pwm_value = 3000000 - array[counter];
    } else {
        pwm_value = 500000 + array[counter];
    }

    pwm_config(pwm_dev, pwm_value, 20000000);
    counter = (counter + 1) % 23;
    comprobator = !comprobator;

    hrtimer_forward(timer, now, ktime_set(0, 50e6));

    return HRTIMER_RESTART;
}

static int __init pwm_module_init(void) {
    int ret;

    pwm_dev = pwm_request(0, "pwm_kernel_module");
    if (IS_ERR(pwm_dev)) {
        printk(KERN_ERR "Failed to request PWM device\n");
        return PTR_ERR(pwm_dev);
    }

    ret = pwm_config(pwm_dev, 0, 20000000);
    if (ret) {
        printk(KERN_ERR "Failed to configure PWM device\n");
        pwm_free(pwm_dev);
        return ret;
    }

    ret = pwm_enable(pwm_dev);
    if (ret) {
        printk(KERN_ERR "Failed to enable PWM device\n");
        pwm_free(pwm_dev);
        return ret;
    }

    hrtimer_init(&pwm_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    pwm_timer.function = pwm_timer_callback;
    hrtimer_start(&pwm_timer, ktime_set(0, 50e6), HRTIMER_MODE_REL);

    return 0;
}

static void __exit pwm_module_exit(void) {
    hrtimer_cancel(&pwm_timer);
    pwm_disable(pwm_dev);
    pwm_free(pwm_dev);
}

module_init(pwm_module_init);
module_exit(pwm_module_exit);