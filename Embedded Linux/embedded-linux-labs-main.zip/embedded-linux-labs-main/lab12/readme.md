# ChatGPR assisted code generation

Review the lab work 4.2 where you created servo control code for hardware PWM. Try to get ChatGPT to generate as similar code as possible. It is possible to iterate within conversation and try variations in output in style "rewrite previous code as linux kernel module". Sometimes the printed output stops in the middle of code. In that case you can try for example "split the previous answer to three parts and reprint the last part".  

Commit the generated code to this folder.
