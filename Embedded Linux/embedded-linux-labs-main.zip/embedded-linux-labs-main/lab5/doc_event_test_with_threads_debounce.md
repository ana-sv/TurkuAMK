# Program Documentation: event_test_with_threads_debounce.c

The `event_test_with_threads_debounce.c` program is designed to test interrupt handling on a set of GPIO lines. It uses the gpiod library to interact with the General Purpose Input/Output (GPIO) pins of a system, as well as POSIX threads to handle the interrupts.

The program defines the following pins:

- BUTTON_PIN - The GPIO pin connected to a push-button switch.
- RED_PIN - The GPIO pin connected to a red LED.
- YELLOW_PIN - The GPIO pin connected to a yellow LED.
- GREEN_PIN - The GPIO pin connected to a green LED.

The program initializes these pins, sets up an interrupt handler for the push-button pin, and enters an infinite loop that toggles the state of the LEDs.

## Functionality

When executed, the program will set up the GPIO pins, including requesting the rising edge event notifications on the push-button pin. The program will then enter an infinite loop, toggling the state of the three LEDs every 200 milliseconds.

When the push-button is pressed, the interrupt handler will be triggered, and the program will print a message to the console indicating that the event occurred. The interrupt handler includes a debounce mechanism to filter out any spurious events that may occur due to electrical noise or bouncing of the switch contacts.

## Requirements

This program requires the `gpiod` library to be installed and available on the system. It is also recommended to have the `pthread` library installed.

## Usage

To compile the program, run the following command:
```
gcc -o event_test event_test.c -lgpiod -lpthread
```


To execute the program, run the following command:
```
sudo ./event_test
```

