# Program Documentation: event_test_with_threads.c

This code uses the `gpiod` library to control four GPIO lines on a Raspberry Pi board. The code initializes a button input line and three output lines that control LEDs.

## GPIO pin configuration

The GPIO pins used in this code are defined at the top of the file:

```c
#define BUTTON_PIN 	22
#define RED_PIN 	23
#define YELLOW_PIN	24
#define GREEN_PIN	25
```
The pin numbers correspond to the BCM pin numbers of the Raspberry Pi.

## Thread function

The thread function `gpio_function` is called to handle events from the button input line. The function waits for a rising edge event on the line and then reads the event details. The function then loops and waits for the next event. The function is passed a structure `gpio_stuff_t` containing information about the GPIO line being monitored.

## Main function

The main function begins by opening a GPIO chip named "gpiochip0". If the chip cannot be opened, the program exits with an error.

The button input line is then acquired and configured to generate rising edge events. The three output lines are also acquired and configured as output lines.

A separate thread is created to handle the button input line events. The thread function is passed a pointer to a `gpio_stuff_t` structure containing the details of the input line to be monitored.

Finally, the main loop of the program toggles the state of the three output lines in sequence every 200ms. The program also releases all acquired GPIO lines and closes the GPIO chip before exiting.

## Error handling

If an error occurs while acquiring or configuring a GPIO line, the program exits with an error code. The error handling code releases any acquired lines and closes the GPIO chip before exiting.
