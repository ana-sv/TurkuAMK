# Program Documentation: event_test_without_threads_debounce.c


## Program Overview
This program is a C program that uses the gpiod library to control GPIO pins on a device. The program sets up four GPIO pins as inputs and outputs, with one pin connected to a push button. The program then waits for events on the button pin, and toggles the state of the other pins in response to those events.


## Dependencies
gpiod library
stdio.h
unistd.h
Pin Configuration
BUTTON_PIN: The pin connected to the push button
RED_PIN: The pin used for the red LED
YELLOW_PIN: The pin used for the yellow LED
GREEN_PIN: The pin used for the green LED


## Main Function
The main function of the program performs the following steps:

- Declares variables for the gpiod_chip and gpiod_line structs, a char* containing the name of the chip to use, and an integer counter.
- Opens the GPIO chip and gets the lines corresponding to the pins defined earlier.
- Sets up the button pin to detect rising edge events, and requests the other pins to be outputs.
- Enters a loop where it toggles the state of the other pins in a specific pattern, and then waits for an event on the button pin.
- When an event is detected, the program reads the event, increments a counter, and then loops back to toggle the pins again.
- Releases the GPIO lines and closes the chip before exiting.

## Directives
This program is wrapped in an #if 1 directive, which means that the program will always be compiled if it is included in a larger program. If you want to exclude this code, you can change #if 1 to #if 0.