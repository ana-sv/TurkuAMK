# Program Documentation: libgpiod-event.c

## Overview
This C code uses the gpiod library to detect events on a specific GPIO line and toggle an LED accordingly.


## Libraries
gpiod.h: provides functions for interacting with GPIO devices

stdio.h: provides standard input/output functions

unistd.h: provides standard symbolic constants and types


## Global Variables
CONSUMER: a preprocessor constant with the value "Consumer", used as a parameter when requesting event notifications on the GPIO line

chipname: a string variable containing the name of the GPIO chip to use

line_num: an unsigned integer variable containing the number of the GPIO pin to use

ts: a struct containing a 1 second timeout value, used when waiting for event notifications

event: a struct containing information about a detected event on the GPIO line

chip: a pointer to a gpiod_chip struct, used to store information about the GPIO chip being used

line: a pointer to a gpiod_line struct, used to store information about the GPIO line being used

i: an integer variable used as a loop counter



## Functions
main(int argc, char **argv): the main function of the program, which handles opening the GPIO chip and line, requesting event notifications, waiting for events to occur, and toggling an LED each time an event is detected.



## Logic
- Initialize global variables and open the GPIO chip using the gpiod_chip_open_by_name() function.
- Get the GPIO line using the gpiod_chip_get_line() function.
- Request event notifications for rising edge events on the GPIO line using the gpiod_line_request_rising_edge_events() function.
- Enter an endless loop, waiting for events to occur on the GPIO line using the gpiod_line_event_wait() function.
- If an event is detected, toggle the LED by setting the value of the GPIO line using the gpiod_line_set_value() function.
- Continue the loop, incrementing the loop counter and waiting for more events to occur.
  


## Limitations
The code only supports event detection for rising edge events on a single GPIO line.
The code assumes that a single LED is connected to the GPIO pin and that toggling the value of the pin will toggle the LED state.