For the time being, instructions for Lab5 are found from OneNote, link below:

https://tuas365.sharepoint.com/sites/EmbeddedLinux/_layouts/15/Doc.aspx?sourcedoc={b2c2950f-461f-44f0-9e2b-078b6b2c7c9d}&action=edit&wd=target%28_Content%20Library%2FLab%20instructions.one%7C42607d48-00a8-4794-be2f-8e7d123bc79e%2FLAB5%20-%20Using%20interrupts%20with%20GPIO%7C04df5e00-3cab-4a43-8e55-ad7f3c2f7aa5%2F%29&wdorigin=703
