#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "MQTTClient.h"

#define ADDRESS "172.27.246.77"         // change to the rapi ip
#define CLIENTID "ExampleClientPub"
#define TOPIC "/home/sensors/temp/kitchen"
#define PAYLOAD "Hello World!"
#define QOS 1
#define TIMEOUT 10000L

#include <gpiod.h>
#include <unistd.h>

#ifndef CONSUMER
#define CONSUMER "Consumer"
#endif

#define BUTTON_PIN 23

int main(int argc, char *argv[])
{

    ////////////////////////////////////////////////////////////////////////////// MQTT config
    MQTTClient client;
    MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
    MQTTClient_message pubmsg = MQTTClient_message_initializer;
    MQTTClient_deliveryToken token;
    int rc;

    MQTTClient_create(&client, ADDRESS, CLIENTID,
                      MQTTCLIENT_PERSISTENCE_NONE, NULL);
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;

    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
    {
        printf("Failed to connect, return code %d\n", rc);
        exit(-1);
    }
    pubmsg.payload = PAYLOAD;
    pubmsg.payloadlen = strlen(PAYLOAD);
    pubmsg.qos = QOS;
    pubmsg.retained = 0;

    ////////////////////////////////////////////////////////////////////////////// Button config
    struct gpiod_chip *chip;
    struct gpiod_line *lineButton;
    struct gpiod_line_event event;
    char *chipname = "gpiochip0";
    int i, counter, ret;
    struct timespec ts = {5, 0}; // we will wait 5sec and then give
    

    /////////////// For button debouncing 
    long int nsec1=0;
    long int sec1=0;
    long int sec2=event.ts.tv_sec;      // seconds 
    long int nsec2=event.ts.tv_nsec;    // nanoseconds 
    long int nowTime; 


    chip = gpiod_chip_open_by_name(chipname);
    if (!chip)
    {
        perror("Open chip failed\n");
        return -1;
    }

    lineButton = gpiod_chip_get_line(chip, BUTTON_PIN);
    if (!lineButton)
    {
        perror("Get line failed\n");
        return -1;
    }

    ret = gpiod_line_request_rising_edge_events(lineButton, CONSUMER);
    if (ret < 0)
    {
        perror("Request event notification failed\n");
        return -1;
    }

    int button_state = 0;
    int last_button_state = 0;

    while (true)
    {

        button_state = gpiod_line_event_read(lineButton, &event);
        if (button_state < 0)
        {
            perror("Read last event notification failed\n");
            return -1;
        }

        if (button_state == 0 && last_button_state != 1)
        {

            sec2=event.ts.tv_sec;      // seconds 
			nsec2=event.ts.tv_nsec;    // nanoseconds 
			nowTime=(sec2 - sec1)*1000000000 + (nsec2 - nsec1);     // = nanoseconds

			if(nowTime>100000000){

            MQTTClient_publishMessage(client, TOPIC, &pubmsg, &token);
            printf("Waiting for up to %d seconds for publication of %s\n"
                   "on topic %s for client with ClientID: %s\n",
                   (int)(TIMEOUT / 1000), PAYLOAD, TOPIC, CLIENTID);

            rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);
            printf("Message with delivery token %d delivered\n", token);

            }

            sec1=sec2;
			nsec1=nsec2;
          
        }

        // Remember the last state of the button
        last_button_state = button_state;

        // Note: we get here only if there were events
        i++;
    }

    MQTTClient_disconnect(client, 10000);
    MQTTClient_destroy(&client);
    gpiod_line_release(lineButton);
    gpiod_chip_close(chip);

    return rc;
}
