# Code Documentation

## Dependencies
stdio.h: Header file for standard input/output operations in C.
stdlib.h: Header file for standard library functions in C.
string.h: Header file for string manipulation functions in C.
MQTTClient.h: Header file for MQTTClient library, which provides MQTT client functionality in C.
gpiod.h: Header file for gpiod library, which provides GPIO access in Linux userspace.
unistd.h: Header file for POSIX operating system API in C.

---

## Macros
- ADDRESS: The IP address of the MQTT broker to connect to.
- CLIENTID: The client ID for the MQTT client.
- TOPIC: The MQTT topic to which messages will be published.
- PAYLOAD: The message payload to be published.
- QOS: The quality of service level for the MQTT message.
- TIMEOUT: The maximum time to wait for MQTT message publication to complete.

---

## Main Function
The main function of the code starts by setting up MQTT configuration using the MQTTClient library. It initializes an MQTT client, sets the connection options (keep alive interval and clean session), and connects to the MQTT broker using the provided IP address and client ID. If the connection fails, an error message is printed and the program exits with a return code of -1.


Next, it sets up button configuration using the gpiod library. It opens a GPIO chip, gets a GPIO line for the specified button pin, and requests rising edge events for the line. If any of these operations fail, an error message is printed and the program exits with a return code of -1.


The code then enters an infinite loop that reads events from the button GPIO line. When a rising edge event is detected, indicating that the button has been pressed, the code checks the time elapsed since the last button press to debounce the button. If the debounce time has elapsed (100ms), it publishes an MQTT message with the specified payload and topic using the MQTTClient_publishMessage function. It then waits for the publication to complete using the MQTTClient_waitForCompletion function, and prints a message indicating that the message has been delivered.


Finally, the code disconnects the MQTT client, releases the GPIO line, closes the GPIO chip, and returns the return code obtained from the MQTTClient_waitForCompletion function.

---

## Summary
The code sets up an MQTT client that publishes a message to a specified topic when a button is pressed, after debouncing the button. It uses the MQTTClient library for MQTT functionality and the gpiod library for GPIO access in Linux userspace.

----