## Documentation "check_level.c"

This documentation provides a simple explanation of a C program that uses the gpiod library to control GPIO pins on a Linux system.

---

## Prerequisites:

- Linux system
- gpiod library installed
- Included Header Files:

        The program includes the following header files:

        - <gpiod.h>: Provides functions to interact with GPIO lines and chips.
        - <stdbool.h>: Provides boolean data type.
        - <stdio.h>: Provides standard input/output functions.
        - <unistd.h>: Provides functions for system calls and other miscellaneous functions.

---

## Global Definitions:

The program defines a default consumer name, "Consumer", which can be changed using the #define directive:
```
#ifndef	CONSUMER
#define	CONSUMER	"Consumer"
#endif
```
---

## Main Function:

The main function is the entry point of the program. It performs the following steps:

- Defines variables and structures for GPIO chip, GPIO lines, and return values.
- Opens a GPIO chip by name using gpiod_chip_open_by_name function and assigns it to the chip variable.
- Gets a GPIO line from the opened chip by line number using gpiod_chip_get_line function and assigns it to the line variable.
- Requests the GPIO line as an input using gpiod_line_request_input function with the consumer name defined earlier.
- Performs the same steps (2-4) for another GPIO pin (line) with a different line number and assigns the chip and line to chip2 and line2 variables respectively.
- Requests the second GPIO line as an output using gpiod_line_request_output function with the consumer name.
- Opens a file in write mode to log the results to a text file.
- Reads the value of the first GPIO line using gpiod_line_get_value function and stores it in the val variable.
- If the value read is less than 0, an error message is printed. Otherwise, it sets the value of the second GPIO line based on the value read from the first GPIO line.
- Releases the resources acquired using gpiod_line_release and gpiod_chip_close functions.
- Closes the file used for logging.
- Returns 0, indicating successful execution of the program.

---

## Usage:

- Compile the program with the gpiod library using an appropriate compiler command.
- Run the compiled program with appropriate permissions to access GPIO pins.
- The program will read the value of the first GPIO line (pin 24) and set the value of the second GPIO line (pin 23) accordingly.
- The results will be logged to a text file named "log.txt" in the same directory as the program.