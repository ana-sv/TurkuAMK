# Documentation for "event_test_with_threads_debounce.c"

---

## Introduction
The "event_test_with_threads_debounce.c" code is a C program that demonstrates the use of threads and the libgpiod library for handling events from a GPIO (General Purpose Input/Output) pin on a Linux-based system. The program uses two threads, one for reading events from a GPIO pin and another for controlling the behavior of an LED or a servo motor based on the events received.

---

## Dependencies
The "event_test_with_threads_debounce.c" code relies on the following libraries:

- stdbool.h: Provides support for boolean data type in C.
- gpiod.h: Provides functions for interacting with GPIO pins on a Linux-based system.
- stdio.h: Provides standard input/output functions in C.
- unistd.h: Provides access to POSIX operating system API in C.
- pthread.h: Provides support for multithreading in C.

--- 

## Pin Definitions
The following GPIO pins are used in the "event_test_with_threads_debounce.c" code:

- BUTTON_PIN: The input pin connected to a push button.
- YELLOW_PIN: The output pin connected to a yellow LED.
- CLOCK: The input pin connected to a clock signal.
- DATA: The input pin connected to a data signal.

---

## Global Variables
The "event_test_with_threads_debounce.c" code uses the following global variables:

- nanoSecondsBefore: Stores the nanoseconds of the previous event timestamp.
- secondsBefore: Stores the seconds of the previous event timestamp.
- ledControl: Controls the behavior of the LED or servo motor based on events received.
- counter1: Stores the counter value for controlling the brightness of the LED or servo motor in one direction.
- counter2: Stores the counter value for controlling the brightness of the LED or servo motor in the other direction.
- tempfile: File pointer for accessing the sysfs interface for controlling the duty cycle of the PWM signal.
- lineGreen: GPIO line object for the green LED.
- linedata: GPIO line object for the data signal.
- lineRed: GPIO line object for the red LED.

---

## Function Definitions
The "event_test_with_threads_debounce.c" code defines the following functions:

- gpio_function(void *args): This function is the entry point for the thread that reads events from the GPIO pin. It waits for events using the gpiod_line_event_wait() function, reads the events using the gpiod_line_event_read() function, and controls the behavior of the LED or servo motor based on the received events.
- main(int argc, char **argv): This is the main function of the program. It initializes the GPIO pins, creates a thread for reading events from the GPIO pin using the pthread_create() function, and waits for the thread to exit using the pthread_join() function.

---

## Usage
To use the "event_test_with_threads_debounce.c" code, follow these steps:

- Compile the code using a C compiler.
- Execute the compiled binary on a Linux-based system with GPIO pins available.
- Connect the push button to the BUTTON_PIN defined in the code.
- Connect the yellow LED to the YELLOW_PIN defined in the code.
- Connect the clock signal to the CLOCK defined in the code.
- Connect the data signal to the DATA defined in the code.
- Observe the behavior of the LED or servo motor based on the events received from the push button and the clock and data signals. The behavior is controlled by the ledControl, counter1, and counter2 variables in the code.

---