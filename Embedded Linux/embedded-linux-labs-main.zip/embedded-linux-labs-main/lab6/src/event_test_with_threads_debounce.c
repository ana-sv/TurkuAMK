/*
 * event_test.c
 *
 *  Created on: Feb 14, 2022
 *      Author: jarno
 */


#if 1

#include <stdbool.h>
#include <gpiod.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

#ifndef CONSUMER
#define CONSUMER "Consumer"
#endif

// Let's define the pins here
#define BUTTON_PIN 25
#define YELLOW_PIN 24
#define CLOCK 22
#define DATA 23

long int nanoSecondsBefore = 0;
long int secondsBefore = 0;
bool ledControl = true;
int counter1 = 0;
int counter2 = 0;
FILE *tempfile;
struct gpiod_line *lineGreen; // Green LED
struct gpiod_line *linedata;  // data line
struct gpiod_line *lineRed;	  // Red LED

typedef struct
{
	unsigned int line_num;
	struct timespec ts;
	struct gpiod_line *line;
} gpio_stuff_t;

void *gpio_function(void *args)
{

	int i, ret;
	struct gpiod_line_event event;
	gpio_stuff_t *actual_args = args;
	i = 0;
	int cont = 0;
	cont++;

	printf("Let's go luteet, says gpio thread\n");
	gpiod_line_set_value(lineGreen, 0);

	while (true)
	{

		ret = gpiod_line_event_wait(actual_args->line, &actual_args->ts);
		if (ret < 0)
		{
			perror("Wait event notification failed\n");
			ret = -1;
			return (void *)(ret);
		}
		else if (ret == 0)
		{
			printf("*");
			fflush(stdout);
			continue;
		}

		ret = gpiod_line_event_read(actual_args->line, &event);
		if (ret < 0)
		{
			perror("Read last event notification failed\n");
			ret = -1;
			return (void *)(ret);
		}

		long int secondsAfter = event.ts.tv_sec;
		long int nanoSecondsAfter = event.ts.tv_nsec;
		long int nowTime = (secondsAfter - secondsBefore) * 1000000000 + (nanoSecondsAfter - nanoSecondsBefore);

		if (nowTime > 20000000)
		{
			int temp = gpiod_line_get_value(linedata);
			printf("\nevent line %d #%d time stamp: %8ld.%09ld secs\n", (actual_args->line_num), i, (long int)event.ts.tv_sec, (long int)event.ts.tv_nsec);
			i++;
			secondsBefore = secondsAfter;
			nanoSecondsBefore = nanoSecondsAfter;

			if (ledControl)
			{
				printf("controling led");
				if (actual_args->line_num == 22)
				{
					if (temp == 0)
					{ // right
						tempfile = fopen("/sys/class/pwm/pwmchip0/pwm0/duty_cycle", "w");

						if (counter1 <= 2500000)
						{
							counter1 = counter1 + 50000;
						}
						fprintf(tempfile, "%d", 500000 + counter1);
						fflush(tempfile);
						fclose(tempfile);
					}
					else if (temp == 1)
					{ // left
						tempfile = fopen("/sys/class/pwm/pwmchip0/pwm0/duty_cycle", "w");
						if (counter1 >= 0)
						{
							counter1 = counter1 - 50000;
						}
						fprintf(tempfile, "%d", 500000 + counter1);
						fflush(tempfile);
						fclose(tempfile);
					}
				}
				else if (actual_args->line_num == 25)
				{
					ledControl = false;
					gpiod_line_set_value(lineGreen, 1);
				}
			}
			else
			{
				printf("controling servo");
				if (actual_args->line_num == 22)
				{
					if (temp == 1)
					{ // brighter
						tempfile = fopen("/sys/class/pwm/pwmchip0/pwm1/duty_cycle", "w");
						if (counter2 <= 25000000)
						{
							counter2 = counter2 + 50000;
						}
						fprintf(tempfile, "%d", counter2);
						fflush(tempfile);
						fclose(tempfile);
					}
					else if (temp == 0)
					{ // dimmer
						tempfile = fopen("/sys/class/pwm/pwmchip0/pwm1/duty_cycle", "w");
						if (counter2 >= 0)
						{
							counter2 = counter2 - 50000;
						}
						fprintf(tempfile, "%d", counter2);
						fflush(tempfile);
						fclose(tempfile);
					}
				}
				if (actual_args->line_num == 25)
				{
					ledControl = true;
					gpiod_line_set_value(lineGreen, 0);
				}
			}
		}
		else
		{
			secondsBefore = secondsAfter;
			nanoSecondsBefore = nanoSecondsAfter;
		}
	}
}

int main(int argc, char **argv)
{

	pthread_t gpio_thread;

	struct gpiod_chip *chip;
	struct gpiod_line *lineButton; // the push button
	struct gpiod_line *lineclock;  // the clock line

	char *chipname = "gpiochip0";

	int i, ret;

	struct timespec ts = {5, 0}; // we will wait 5sec and then give up
	//*****************************************************************************************
	// open the pins
	tempfile = fopen("/sys/class/pwm/pwmchip0/export", "w");
	fprintf(tempfile, "%d", 0);
	fclose(tempfile);
	tempfile = fopen("/sys/class/pwm/pwmchip0/pwm0/period", "w");
	fprintf(tempfile, "%d", 20000000);
	fclose(tempfile);
	tempfile = fopen("/sys/class/pwm/pwmchip0/pwm0/enable", "w");
	fprintf(tempfile, "%d", 1);
	fclose(tempfile);
	tempfile = fopen("/sys/class/pwm/pwmchip0/pwm1/period", "w");
	fprintf(tempfile, "%d", 20000000);
	fclose(tempfile);
	tempfile = fopen("/sys/class/pwm/pwmchip0/pwm1/enable", "w");
	fprintf(tempfile, "%d", 1);
	fclose(tempfile);
	/*****************************************************************************************************/
	chip = gpiod_chip_open_by_name(chipname);
	if (!chip)
	{
		perror("Open chip failed\n");
		ret = -1;
		goto end;
	}

	lineButton = gpiod_chip_get_line(chip, BUTTON_PIN);
	if (!lineButton)
	{
		perror("Get line failed\n");
		ret = -1;
		goto close_chip;
	}

	ret = gpiod_line_request_rising_edge_events(lineButton, CONSUMER);
	if (ret < 0)
	{
		perror("Request event notification failed\n");
		ret = -1;
		goto release_line;
	}
	lineclock = gpiod_chip_get_line(chip, CLOCK);
	if (!lineclock)
	{
		perror("Get line failed\n");
		ret = -1;
		goto close_chip;
	}

	ret = gpiod_line_request_falling_edge_events(lineclock, CONSUMER);
	if (ret < 0)
	{
		perror("Request event notification failed\n");
		ret = -1;
		goto release_line;
	}
	linedata = gpiod_chip_get_line(chip, DATA);
	if (!linedata)
	{
		perror("Get line failed\n");
		ret = -1;
		goto close_chip;
	}

	ret = gpiod_line_request_input(linedata, CONSUMER);
	if (ret < 0)
	{
		perror("Request event notification failed\n");
		ret = -1;
		goto release_line;
	}

	// Open more GPIO lines, skip error checking...

	lineGreen = gpiod_chip_get_line(chip, YELLOW_PIN);

	gpiod_line_request_output(lineGreen, "example1", 0);

	lineGreen = gpiod_chip_get_line(chip, YELLOW_PIN);

	// pthread_create accepts only one argument to be passed to the function,
	// so let's create a struct and provide a pointer to it
	gpio_stuff_t gpio_stuff;
	gpio_stuff_t gpio_stuff_a;
	gpio_stuff_t gpio_stuff_b;

	gpio_stuff.line = lineButton;
	gpio_stuff.line_num = BUTTON_PIN;
	gpio_stuff.ts = ts;

	gpio_stuff_a.line = lineclock;
	gpio_stuff_a.line_num = CLOCK;
	gpio_stuff_a.ts = ts;

	ret = pthread_create(&gpio_thread, NULL, gpio_function, (&gpio_stuff));
	ret = pthread_create(&gpio_thread, NULL, gpio_function, &gpio_stuff_a);

	/* The eternal main loop */
	i = 0;
	while (true)
	{

		usleep(200e3); // 200msecs

		i++;
	}

	ret = 0;

release_line: // generally.... don't use use "goto"s. Error handlers are the only justified place

	gpiod_line_release(lineclock);
	gpiod_line_release(lineGreen);
	gpiod_line_release(linedata);
	gpiod_line_release(lineButton);

close_chip:
	gpiod_chip_close(chip);

end:
	return ret;
}
#endif