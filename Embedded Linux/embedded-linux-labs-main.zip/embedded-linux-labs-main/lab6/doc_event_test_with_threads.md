# Documentation for "event_test_with_threads.c"
The "event_test_with_threads.c" file is a C program that demonstrates how to use the libgpiod library to interact with GPIO (General Purpose Input/Output) pins on a Linux system. The program sets up three threads that monitor the falling edge events on three different GPIO pins: a button pin (BUTTON_PIN), a potentiometer pin A (POTENT_PIN_A), and a potentiometer pin B (POTENT_PIN_B). When a falling edge event is detected on any of these pins, the corresponding thread prints a message indicating that an event has occurred.

The program also uses another GPIO pin (YELLOW_PIN) as an output to blink an LED. The LED is toggled on and off at a rate determined by a counter variable.

---

## Dependencies
The "event_test_with_threads.c" program requires the following header files to be included:

- gpiod.h: Header file for the libgpiod library, which provides functions for interacting with GPIO pins.
- stdio.h: Header file for standard input/output operations in C.
- unistd.h: Header file for POSIX operating system API, including the usleep() function used for delaying execution in microseconds.
- pthread.h: Header file for POSIX threads, used for creating and managing threads in the program.
  
--- 

## Pins Configuration
The program defines four GPIO pins that are used in the demonstration:

- BUTTON_PIN: The pin number of the button GPIO pin.
- YELLOW_PIN: The pin number of the yellow LED GPIO pin.
- POTENT_PIN_A: The pin number of the potentiometer pin A GPIO pin.
- POTENT_PIN_B: The pin number of the potentiometer pin B GPIO pin.

These pin numbers are used to request and configure GPIO lines using the libgpiod library functions.

---

## Function Documentation
- void gpio_function(void *args) -> This function is the entry point for the threads that monitor the falling edge events on the GPIO pins. It takes a void pointer as an argument, which is cast to a gpio_stuff_t structure pointer that contains information about the GPIO line to be monitored, such as the line number, timestamp, and line pointer. The function enters an infinite loop and waits for falling edge events on the specified GPIO line using the gpiod_line_event_wait() function. When an event is detected, the function prints a message indicating the line number and the number of times an event has occurred.

- int main(int argc, char **argv) -> This is the main function of the program. It initializes the GPIO chip, requests and configures the GPIO lines for the button, potentiometer A, potentiometer B, and yellow LED, and creates three threads that call the gpio_function() function with different arguments for each GPIO line. The main function also contains an eternal loop that toggles the yellow LED on and off at a rate determined by a counter variable.

---

## Error Handling
The program uses error checking and error handling to detect and handle any failures in GPIO operations or thread creation. If an error occurs, an error message is printed to stderr and the program returns with a non-zero exit code to indicate an error has occurred.

---

## Usage
To compile and run the "event_test_with_threads.c" program, you need to have the libgpiod library installed on your Linux system. You can compile the program using gcc with the following command:

```
gcc -o event_test_with_threads event_test_with_threads.c -lgpiod -lpthread
```
This will generate an executable file named "event_test_with_threads". You can then run the program as follows:
```
./event_test_with_threads
```

---