# Documentation for "event_test_without_threads.c"

This file contains a C program that demonstrates how to use the libgpiod library to handle events from GPIO pins without using threads. It sets up event notifications on two GPIO pins (POTENT_PIN_A and POTENT_PIN_B) for rising edge events, and blinks two other GPIO pins (YELLOW_PIN and GREEN_PIN) as an example. The program waits for events using the gpiod_line_event_wait() function, and reads the events using the gpiod_line_event_read() function.

---

## Dependencies
gpiod.h: This header file contains the definitions for the functions and data structures used to interact with GPIO pins using the libgpiod library.
stdio.h: This header file contains standard input/output functions, such as printf() and perror(), used for printing messages to the console.
unistd.h: This header file contains functions related to POSIX operating system API, such as usleep(), used for pausing the program execution.

---
## Pin Definitions
- POTENT_PIN_A: This constant defines the GPIO pin number for the first push button.
- POTENT_PIN_B: This constant defines the GPIO pin number for the second push button.
- YELLOW_PIN: This constant defines the GPIO pin number for the yellow LED.
- GREEN_PIN: This constant defines the GPIO pin number for the green LED.

---

## Functions
main(): This is the entry point of the program. It initializes the libgpiod library, sets up event notifications for the push buttons, requests output lines for the LEDs, and enters a loop to wait for and handle events. It also blinks the LEDs as an example. The program exits when an error occurs or when interrupted by a signal.

---

## Usage
- Compile and link the program with the libgpiod library using a suitable compiler command.
- Execute the compiled binary to run the program.
- The program waits for events on the push buttons (POTENT_PIN_A and POTENT_PIN_B) and blinks the LEDs (YELLOW_PIN and GREEN_PIN) based on the events received.
- Press the push buttons to generate events and observe the LED blinking behavior.
- The program can be terminated by pressing Ctrl+C or by sending a signal to the process.