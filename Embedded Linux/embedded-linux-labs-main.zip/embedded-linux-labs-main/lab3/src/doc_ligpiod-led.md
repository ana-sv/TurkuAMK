# Program Documentation : ligpio-led.c
Submission of code use for assignment 1
___

This program uses the gpiod library to control a GPIO pin on a Linux system. It opens the GPIO chip "gpiochip0" and requests GPIO line 23 as an output. Then, it sets the value of the output to toggle the LED connected to that pin in an endless loop with a 1-second delay between each toggle.

## Dependencies
This program requires the `gpiod` library to be installed on the system.

## Usage
Compile the program using a C compiler and run the resulting executable file. The program will run indefinitely until interrupted manually.

## Modification
- To change the GPIO pin that is controlled, modify the `line_num` variable to the desired GPIO pin number.
- To change the delay between each toggle, modify the `sleep()` function call in the infinite loop.

## Code Explanation
1. The necessary libraries and header files are included at the beginning of the program.
2. The `main()` function begins by defining variables for the chip name, line number, and the `gpiod_chip` and `gpiod_line` structures used to interact with the GPIO pin.
3. The program attempts to open the specified GPIO chip using `gpiod_chip_open_by_name()`.
4. If the chip is opened successfully, the program attempts to get the specified GPIO line using `gpiod_chip_get_line()`.
5. If the line is retrieved successfully, the program requests the line as an output using `gpiod_line_request_output()`.
6. If the line is successfully requested as an output, the program enters an infinite loop that toggles the output value of the GPIO line every 1 second using `gpiod_line_set_value()`.
7. If any errors occur during the program execution, the program releases the GPIO line and closes the GPIO chip using `gpiod_line_release()` and `gpiod_chip_close()`, respectively.

