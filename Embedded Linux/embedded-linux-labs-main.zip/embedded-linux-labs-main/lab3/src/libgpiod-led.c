// assignment 1

#include <gpiod.h>
#include <stdbool.h>
#include <stdio.h>
#include <unistd.h>

#ifndef	CONSUMER
#define	CONSUMER	"Consumer"
#endif 


#if	1

int main(int argc, char **argv)
{
	char *chipname = "gpiochip0";
	unsigned int line_num = 23;	// GPIO Pin #23
	unsigned int val;
	struct gpiod_chip *chip;
	struct gpiod_line *line;
	int i, ret;

	chip = gpiod_chip_open_by_name(chipname);
	if (!chip) {
		perror("Open chip failed\n");
		goto end;
	}

	line = gpiod_chip_get_line(chip, line_num);
	if (!line) {
		perror("Get line failed\n");
		goto close_chip;
	}

	ret = gpiod_line_request_output(line, CONSUMER, 0);
	if (ret < 0) {
		perror("Request line as output failed\n");
		goto release_line;
	}

	/* Blink 20 times */
	val = 0;
	while (true) {     // (1) the program was changed so that it blinks in an endless loop 
		ret = gpiod_line_set_value(line, val);
		if (ret < 0) {
			perror("Set line output failed\n");
			goto release_line;
		}
		//printf("Output %u on line #%u\n", val, line_num); // (4) Remove the printf()-call (comment it out) (6) add the printf back
		// fflush(stdout);  // (7) add fflush  (8) comment out the fflush 

		sleep(1);
		//usleep(1000); // (2) : 1 millisecond = 1000 us 
		// unsleep(1); // (3) : 1 us     (5)  Remove the 1us delay (comment it out) 

		val = !val;
	}

release_line:
	gpiod_line_release(line); 
close_chip:
	gpiod_chip_close(chip);
end:
	return 0;
}

#endif