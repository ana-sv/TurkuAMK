// assignment 2

#include <gpiod.h>
#include <stdio.h>
#include <unistd.h>

#ifndef CONSUMER
#define CONSUMER "Consumer"
#endif

int main(int argc, char **argv)
{
	char *chipname = "gpiochip0";
	unsigned int line_num = 24;	   // GPIO Pin #24 , led
	unsigned int line_button = 23; // GPIO Pin #23, button
	int val;
	struct gpiod_chip *chip;
	struct gpiod_line *line;
	int i, ret;
	struct gpiod_chip *chipButton;
	struct gpiod_line *lineButton;
	int retButton;

	chip = gpiod_chip_open_by_name(chipname);
	if (!chip)
	{
		perror("Open chip failed\n");
		goto end;
	}

	line = gpiod_chip_get_line(chip, line_num);
	if (!line)
	{
		perror("Get line failed\n");
		goto close_chip;
	}

	ret = gpiod_line_request_input(line, CONSUMER);
	if (ret < 0)
	{
		perror("Request line as input failed\n");
		goto release_line;
	}

	chipButton = gpiod_chip_open_by_name(chipname);
	if (!chipButton)
	{
		perror("Open chip failed\n");
		goto release_line;
	}

	lineButton = gpiod_chip_get_line(chipButton, line_button);
	if (!lineButton)
	{
		perror("Get line failed\n");
		goto close_button_chip;
	}

	retButton = gpiod_line_request_output(lineButton, CONSUMER, 0);
	if (retButton < 0)
	{
		perror("Request line as output failed\n");
		goto release_button_line;
	}
	int counter = 0;
	int counterButton = 0;
	FILE *fptr;

	while (true)
	{

		val = gpiod_line_get_value(line);
		if (val < 0)
		{
			perror("Read line input failed\n");
			goto release_line;
		}
		else if (val == 1)
		{
			counter++;
		}
		else
		{

			fptr = fopen("messageFile.txt", "a");
			if (fptr == NULL)
			{
				perror("Error opening file for appending");
				exit(1);
			}

			fprintf(fptr, "%dms,", counter);
			fclose(fptr);

			while ((counter / 100) > 0)
			{
				counter--;

				if (counterButton < 10)
				{
					retButton = gpiod_line_set_value(lineButton, 1);
					if (retButton < 0)
					{
						perror("Failed to set line value");
						goto release_button_line;
					}

					counterButton++;
				}
				else if (counterButton < 100)
				{
					retButton = gpiod_line_set_value(lineButton, 0);
					if (retButton < 0)
					{
						perror("Failed to set line value");
						goto release_button_line;
					}
					counterButton++;
				}
				else
				{
					counterButton = 0;
				}

				usleep(1000);
			}
		}
		usleep(1000);
	}

release_button_line:
	gpiod_line_release(lineButton);
close_button_chip:
	gpiod_chip_close(chipButton);
release_line:
	gpiod_line_release(line);
close_chip:
	gpiod_chip_close(chip);
end:
	return 0;
}