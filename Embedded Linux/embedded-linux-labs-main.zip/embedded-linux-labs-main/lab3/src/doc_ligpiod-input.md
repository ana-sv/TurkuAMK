# Program Documentation : ligpio-input.c

 Code Submission for assignment 2
____

## Description
This C code is designed to control an LED using a push-button connected to a Raspberry Pi's GPIO pins. The code uses the `gpiod` library to access and control the GPIO pins.

## Dependencies
- gpiod library
- stdio.h library
- unistd.h library

## Usage
1. Compile the code using a C compiler.
2. Run the compiled code.

## Input Parameters
The code takes no input parameters.

## Output
The code controls an LED using a push-button connected to the GPIO pins of a Raspberry Pi.

## Code Breakdown
1. The necessary libraries are imported.
2. The GPIO chip and lines are defined using the `gpiod` library.
3. The input and output of the GPIO pins are requested and checked for errors.
4. A file named "messageFile.txt" is created and appended with the time duration the button was pressed in milliseconds.
5. The LED is controlled using the push-button.

## Function Descriptions

### Main Function
The main function initiates the connection with the GPIO pins and runs an infinite loop to control the LED using the push-button. The loop continuously reads the input of the push-button and records the duration the button is pressed. When the button is released, the recorded duration is appended to a file and the LED is controlled using the push-button.

### Libraries
The `gpiod` library is used to access and control the GPIO pins. The `stdio.h` library is used for file I/O, and the `unistd.h` library is used for `usleep` function.

### Variables
- `chipname` is a string that defines the GPIO chip name.
- `line_num` is an integer that defines the GPIO pin number for the LED.
- `line_button` is an integer that defines the GPIO pin number for the push-button.
- `val` is an integer that stores the value of the push-button input.
- `chip` is a pointer to a `gpiod_chip` structure that represents the GPIO chip for the LED.
- `line` is a pointer to a `gpiod_line` structure that represents the GPIO pin for the LED.
- `ret` is an integer that stores the return value of the `gpiod_line_request_input` function.
- `chipButton` is a pointer to a `gpiod_chip` structure that represents the GPIO chip for the push-button.
- `lineButton` is a pointer to a `gpiod_line` structure that represents the GPIO pin for the push-button.
- `retButton` is an integer that stores the return value of the `gpiod_line_request_output` function.
- `counter` is an integer that stores the duration the button is pressed in milliseconds.
- `counterButton` is an integer that stores the current state of the LED.

### Error Handling
The code uses the `perror` function to display an error message to the console in case of an error. In case of an error, the code releases the resources and exits gracefully.

### Code Limitations
- The code assumes that the GPIO chip name is `gpiochip0`.
- The code assumes that the LED is connected to GPIO pin #24, and the push-button is connected to GPIO pin #23.
- The code assumes that the push-button is wired to the GPIO pin in a way that pressing the button connects the GPIO pin to ground.
- The code writes the duration the button is pressed to a file named "messageFile.txt" in the same directory as the code.
