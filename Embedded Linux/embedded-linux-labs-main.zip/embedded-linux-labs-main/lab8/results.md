
## QUESTION 1
### From the VM, get default page content to file using curl http://x.x.x.x > placeholderpage.html, put it into lab8/results repo path, commit and push. Note that the placeholder page contains relevant information for setting up the service, so you might want to look at it later as well.

```
student@student-VirtualBox:~$ curl http://172.27.246.77> placeholderpage.html
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100  3388  100  3388    0     0  1654k      0 --:--:-- --:--:-- --:--:-- 1654k
student@student-VirtualBox:~$ 

```
---

## QUESTION 2
### Where did you find information on which file and line your error was? Get the relevant error message to file errors.txt, put it into lab8/results repo path, commit and push.


```
pi@easyname:~ $ sudo systemctl status lighttpd.service
● lighttpd.service - Lighttpd Daemon
     Loaded: loaded (/lib/systemd/system/lighttpd.service; enabled; vendor preset: en>
     Active: failed (Result: exit-code) since Mon 2023-03-13 08:40:59 GMT; 1min 39s a>
    Process: 7568 ExecStartPre=/usr/sbin/lighttpd -tt -f /etc/lighttpd/lighttpd.conf >
        CPU: 367ms

Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Scheduled restart job, restart>
Mar 13 08:40:59 easyname systemd[1]: Stopped Lighttpd Daemon.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Start request repeated too qui>
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:59 easyname systemd[1]: Failed to start Lighttpd Daemon.

pi@easyname:~ $ sudo tail -20 /var/log/lighttpd/error.log
2023-03-13 07:55:17: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:40:55: server.c.949) [note] graceful shutdown started
2023-03-13 08:40:55: server.c.1976) server stopped by UID = 0 PID = 7542
pi@easyname:~ $ sudo tail -20 /var/log/syslog
Mar 13 08:40:58 easyname systemd[1]: Failed to start Lighttpd Daemon.
Mar 13 08:40:58 easyname systemd[1]: lighttpd.service: Scheduled restart job, restart counter is at 4.
Mar 13 08:40:58 easyname systemd[1]: Stopped Lighttpd Daemon.
Mar 13 08:40:58 easyname systemd[1]: Starting Lighttpd Daemon...
Mar 13 08:40:58 easyname lighttpd[7563]: 2023-03-13 08:40:58: configfile.c.1970) source: /etc/lighttpd/lighttpd.conf line: 58 pos: 1 parser failed somehow near here: rhfesyc
Mar 13 08:40:58 easyname systemd[1]: lighttpd.service: Control process exited, code=exited, status=255/EXCEPTION
Mar 13 08:40:58 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:58 easyname systemd[1]: Failed to start Lighttpd Daemon.
Mar 13 08:40:58 easyname systemd[1]: lighttpd.service: Scheduled restart job, restart counter is at 5.
Mar 13 08:40:58 easyname systemd[1]: Stopped Lighttpd Daemon.
Mar 13 08:40:58 easyname systemd[1]: Starting Lighttpd Daemon...
Mar 13 08:40:59 easyname lighttpd[7568]: 2023-03-13 08:40:58: configfile.c.1970) source: /etc/lighttpd/lighttpd.conf line: 58 pos: 1 parser failed somehow near here: rhfesyc
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Control process exited, code=exited, status=255/EXCEPTION
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:59 easyname systemd[1]: Failed to start Lighttpd Daemon.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Scheduled restart job, restart counter is at 6.
Mar 13 08:40:59 easyname systemd[1]: Stopped Lighttpd Daemon.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Start request repeated too quickly.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:59 easyname systemd[1]: Failed to start Lighttpd Daemon.


```

---

## QUESTION 3: 
### Copypaste a snippet of log output showing verbose content to file lab8/accesslog.log, commit and push.

```
pi@easyname:~ $  sudo systemctl status lighttpd.service
● lighttpd.service - Lighttpd Daemon
     Loaded: loaded (/lib/systemd/system/lighttpd.service; enabled; vendor preset: en>
     Active: active (running) since Mon 2023-03-13 08:47:08 GMT; 10min ago
    Process: 7617 ExecStartPre=/usr/sbin/lighttpd -tt -f /etc/lighttpd/lighttpd.conf >
    Process: 7717 ExecReload=/bin/kill -USR1 $MAINPID (code=exited, status=0/SUCCESS)
   Main PID: 7622 (lighttpd)
      Tasks: 1 (limit: 4915)
        CPU: 2.374s
     CGroup: /system.slice/lighttpd.service
             └─7622 /usr/sbin/lighttpd -D -f /etc/lighttpd/lighttpd.conf

Mar 13 08:47:07 easyname systemd[1]: Starting Lighttpd Daemon...
Mar 13 08:47:08 easyname systemd[1]: Started Lighttpd Daemon.
Mar 13 08:47:52 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:47:52 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:49:02 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:49:02 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:50:54 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:50:54 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:57:35 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:57:35 easyname systemd[1]: Reloaded Lighttpd Daemon.

pi@easyname:~ $ sudo tail -20 /var/log/lighttpd/error.log
2023-03-13 07:55:17: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:40:55: server.c.949) [note] graceful shutdown started
2023-03-13 08:40:55: server.c.1976) server stopped by UID = 0 PID = 7542
2023-03-13 08:47:08: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:47:52: server.c.949) [note] graceful shutdown started
2023-03-13 08:47:52: server.c.1976) server stopped by UID = 0 PID = 7635
2023-03-13 08:47:52: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:49:02: server.c.949) [note] graceful shutdown started
2023-03-13 08:49:02: server.c.1976) server stopped by UID = 0 PID = 7651
2023-03-13 08:49:02: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:50:54: server.c.949) [note] graceful shutdown started
2023-03-13 08:50:54: server.c.1976) server stopped by UID = 0 PID = 7676
2023-03-13 08:50:54: server.c.1513) server started (lighttpd/1.4.59)
2023-03-13 08:57:35: server.c.949) [note] graceful shutdown started
2023-03-13 08:57:35: server.c.1976) server stopped by UID = 0 PID = 7717
2023-03-13 08:57:35: server.c.1513) server started (lighttpd/1.4.59)
pi@easyname:~ $ sudo tail -20 /var/log/syslog
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:59 easyname systemd[1]: Failed to start Lighttpd Daemon.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Scheduled restart job, restart counter is at 6.
Mar 13 08:40:59 easyname systemd[1]: Stopped Lighttpd Daemon.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Start request repeated too quickly.
Mar 13 08:40:59 easyname systemd[1]: lighttpd.service: Failed with result 'exit-code'.
Mar 13 08:40:59 easyname systemd[1]: Failed to start Lighttpd Daemon.
Mar 13 08:43:14 easyname dhcpcd[464]: eth0: failed to renew DHCP, rebinding
Mar 13 08:46:31 easyname systemd[1]: lighttpd.service: Unit cannot be reloaded because it is inactive.
Mar 13 08:47:07 easyname systemd[1]: Starting Lighttpd Daemon...
Mar 13 08:47:08 easyname systemd[1]: Started Lighttpd Daemon.
Mar 13 08:47:52 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:47:52 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:49:02 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:49:02 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:50:54 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:50:54 easyname systemd[1]: Reloaded Lighttpd Daemon.
Mar 13 08:51:34 easyname dhcpcd[464]: eth0: failed to renew DHCP, rebinding
Mar 13 08:57:35 easyname systemd[1]: Reloading Lighttpd Daemon.
Mar 13 08:57:35 easyname systemd[1]: Reloaded Lighttpd Daemon.
pi@easyname:~ $ 

```
---

## QUESTION 4:  
### From the VM, get default page content to file using curl https://x.x.x.x > httpspage.html, put it into lab8/results repo path, commit and push.

```
student@student-VirtualBox:~$ curl http://172.27.246.77> placeholderpage.html
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100  3388  100  3388    0     0   827k      0 --:--:-- --:--:-- --:--:--  827k
student@student-VirtualBox:~$ 

```

----

## QUESTION 5:
### From the VM, get default page content to file using curl https://x.x.x.x/orig > mypage.html, put it into lab8/results repo path, commit and push.
```
student@student-VirtualBox:~/embedded-linux-labs/lab8$ curl http://172.27.246.77> orig/placeholderpage.html
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100  3388  100  3388    0     0  1102k      0 --:--:-- --:--:-- --:--:-- 1102k
student@student-VirtualBox:~/embedded-linux-labs/lab8$ 

```
