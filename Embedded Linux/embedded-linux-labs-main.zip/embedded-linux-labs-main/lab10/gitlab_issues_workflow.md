
# Issues Workflow

1. create issues ( atention to detlais: description, tags... ); 
2. solve issues in "fixing-issues" branch 
3. close all issues 
4. merge back to main branch 
