#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include "yuarel.h"
#include <string.h>

#define BUFSIZE 500
FILE *tempfile;
int main(void)
{
	int p;
	struct yuarel url;
	char *parts[3];
	char content[BUFSIZE];
	struct yuarel_param params[3];
	int servo_position = -1;
	char command[100] = "echo ";
	char *env = "QUERY"; 

	if(!getenv(env)){
		fprintf(stderr,"The environment variable %s was not found\n",env);
		exit(1);
	}
	 if(snprintf(content,BUFSIZE, "%s",getenv(env))>=BUFSIZE){
		fprintf(stderr,"BUFSIZE of %d was too small. Aborting\n",BUFSIZE);
		exit(1);
	 }

	// setting up environment variables for PWM channel on the device represented by pwmchip0
	system("echo 0 > /sys/class/pwm/pwmchip0/export");
	system("echo 2000000000 > /sys/class/pwm/pwmchip0/pwm0/period"); // 2000000000 nanoseconds (2 seconds)
	system("echo 0 > /sys/class/pwm/pwmchip0/pwm0/duty_cycle");
	system("echo 1> /sys/class/pwm/pwmchip0/pwm0/enable");

	p = yuarel_parse_query(content, '&', params, 3);
	while (p-- > 0)
	{
		printf("\t%s: %s\n", params[p].key, params[p].val);

		// if it detects the servo positon
		if (strcmp("servoposition",params[p].key) == 0)
		{
			tempfile=fopen("/sys/class/pwm/pwmchip0/pwm0/duty_cycle" , "w");
			fprintf(tempfile, "%s",params[0].val);
			fflush(tempfile);
			fclose(tempfile);

		}
	}
}