# CGI Environment Variables Viewer
This C code is a simple CGI (Common Gateway Interface) program that displays the environment variables in a web browser. The program takes the environment variables provided by the web server and displays them in an HTML table.

---

## Functions
The code includes the following functions:

- print_http_header(const char *content_type): This function prints a basic HTTP header with the specified content type.

- cgi_fail(const char *message): This function handles errors by printing a plain text error message and then exits the program.

- find_equals(const char *s): This function finds the position of the first equals sign ("=") in the input string s. It returns the position if found, or -1 if not found.

- split_env_var(const char *variable, env_var *ev): This function splits an environment variable string into the part before the equals sign and the part after the equals sign. It stores the result in the ev structure, which contains two members: name and value.

- count_env_vars(): This function counts the number of environment variables provided by the web server by iterating through the environ array. If the number of environment variables exceeds the predefined limit _ENV_VAR_GIVE_UP, an error message is printed and the program exits.

- get_environment(env_var *env_vars, int n_env_vars): This function populates the env_vars array with the environment variables provided by the web server by calling split_env_var() for each environment variable.

- main(): This is the entry point of the program. It calls count_env_vars() to get the number of environment variables, allocates memory for the env_vars array, and then calls get_environment() to populate the array. It then prints an HTML header, displays the environment variables in an HTML table, and frees the memory allocated for the env_vars array before returning 0 to indicate a successful execution.

---

## Usage
Compile the code using a C compiler, e.g., gcc:
```
gcc -o cgi_env_vars cgi_env_vars.c
```
- Upload the compiled binary (cgi_env_vars) to your web server's CGI directory.

- Set the appropriate permissions on the binary to allow it to be executed by the web server.

- Access the CGI program through a web browser to see the environment variables displayed in an HTML table.

---

Note: This code is intended for educational purposes and should be used with caution in a production environment, as it may expose sensitive information. Proper security measures should be implemented to protect against potential vulnerabilities.

---