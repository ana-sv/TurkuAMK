# Documentation for " yarel.c"

yuarel is a C library for parsing URLs. It provides functions to parse a URL string into its constituent parts, such as scheme, host, port, path, query, and fragment.

---

## Functions:

- int yuarel_parse(struct yuarel *url, char *u): This function parses a URL string into a struct yuarel that contains the parsed URL parts. It takes a pointer to a struct yuarel and a URL string u as input. It returns 0 on success and -1 on failure.

- static inline int is_relative(const char *url): This function checks if a URL is relative (i.e., it does not contain a scheme and hostname). It takes a URL string as input and returns 1 if the URL is relative, otherwise 0.

- static inline char *parse_scheme(char *str): This function parses the scheme of a URL by inserting a null terminator after the scheme. It takes a URL string as input and returns a pointer to the hostname on success, otherwise NULL.

- static inline char *find_and_terminate(char *str, char find): This function finds a character in a string, replaces it with '\0', and returns the next character in the string. It takes a string str and a character to search for find as input. It returns a pointer to the character after the one to search for. If the character is not found, NULL is returned.

- static inline char *find_fragment(char *str): This function finds the fragment part of a URL and terminates the string after the fragment by replacing '#' with '\0'. It takes a URL string as input and returns a pointer to the character after the fragment.

- static inline char *find_query(char *str): This function finds the query part of a URL and terminates the string after the query by replacing '?' with '\0'. It takes a URL string as input and returns a pointer to the character after the query.

- static inline char *find_path(char *str): This function finds the path part of a URL and terminates the string after the path by replacing '/' with '\0'. It takes a URL string as input and returns a pointer to the character after the path.

- static inline int natoi(const char *str, size_t len): This function parses a non-null terminated string into an integer. It takes a string str and the number of characters to parse len as input, and returns the parsed integer.

- static inline int yuarel_parse(struct yuarel *url, char *u): This is an alias for yuarel_parse(struct yuarel *url, char *u), which parses a URL string into a struct yuarel that contains the parsed URL parts. It takes a pointer to a struct yuarel and a URL string u as input. It returns 0 on success and -1 on failure.

- struct yuarel: This is a struct that holds the parsed URL parts, including scheme, username, password, host, port, path, query, and fragment, as character pointers.

---


## Note: 
The functions in this library operate on the input string directly and modify it by inserting null terminators. Therefore, the input URL string should be a mutable string. The parsed URL parts are stored as character pointers within the input string and do not require any additional memory allocation.