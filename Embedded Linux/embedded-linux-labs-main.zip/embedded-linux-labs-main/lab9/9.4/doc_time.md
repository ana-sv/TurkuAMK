# time.cgi - C CGI Program to Retrieve Current Time as JSON
The time.cgi is a C CGI (Common Gateway Interface) program that retrieves the current time as JSON format. It can be compiled and executed on a Raspberry Pi (raspi) or any other compatible system.

----

## Compilation
To compile the time.cgi program locally on a Raspberry Pi, you can use gcc, a popular C compiler. Open a terminal window and navigate to the directory where the time.c file is located. Then, run the following command:
```
gcc time.c -o time.cgi
```
This will compile the time.c file into an executable named time.cgi.

----

### Copying Executable
After compilation, you can copy the time.cgi executable to the /usr/lib/cgi-bin directory on your Raspberry Pi. This is a common location for storing CGI scripts on Linux systems. You may need administrator (root) privileges to copy the file to this directory. You can use the following command to copy the time.cgi executable:

```
sudo cp time.cgi /usr/lib/cgi-bin
```

----

## Usage
Once the time.cgi executable is copied to the /usr/lib/cgi-bin directory, it can be accessed via a web server or directly through the browser. When accessed, the time.cgi program will return the current time in JSON format as the HTTP response.

The HTTP response will include the following headers:

Status: 200 OK: Indicates a successful HTTP response.
Content-type: application/json: Indicates that the response body will be in JSON format.
The response body will be a JSON object containing a single field named "time" with the value set to the current time in a string format.

--- 

## Example Response:

```
{
  "time": "Sat Apr 15 12:34:56 2023"
}
```

## Note: 
The time function is used to retrieve the current time in seconds since the epoch (January 1, 1970), and the ctime_r function is used to convert the time value into a human-readable string format. The resulting string is encapsulated in a JSON object and printed to the standard output (stdout) as the HTTP response.