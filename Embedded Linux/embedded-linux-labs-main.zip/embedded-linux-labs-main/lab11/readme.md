# ChatGPT assisted code documentation

Ask ChatGPT to produce documentation for all previous lab codes. Add the generated documentation to doc_filename.md files in corresponding lab folders (use markdown format) and commit. Maybe you could ask chatgpt to generate documentation in md format?
